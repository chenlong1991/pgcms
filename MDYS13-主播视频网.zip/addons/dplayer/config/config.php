<?php
$player=array (
  'ads' => 
  array (
    'status' => '1',
    'vip' => '0',
    'group' => '1',
  ),
  'pre' => 
  array (
    'status' => '1',
    'url' => 'https://ae01.alicdn.com/kf/H9eaa65d8fde748a4bdc554a02004c3437.png',
  ),
  'logo' => 
  array (
    'status' => '1',
    'url' => 'https://ae01.alicdn.com/kf/H8b27efd72b3943a9af5d65f58644d255K.png',
  ),
  'copyright' => 
  array (
    'status' => '1',
    'content' => '麻豆源码',
    'url' => 'https://madouym.com',
  ),
  'dp' => 
  array (
    'auto' => '1',
    'last' => '1',
    'next' => '1',
    'h5' => NULL,
  ),
);
$pre=array (
  'ads' => 
  array (
    'status' => '1',
    'time' => '60',
    'button' => '1',
    'auth' => '0',
    'group' => '3',
  ),
  'pic' => 
  array (
    'status' => '1',
    'img' => 'https://ae01.alicdn.com/kf/H9eaa65d8fde748a4bdc554a02004c3437.png',
    'link' => 'https://madouym.com',
    'width' => '',
    'height' => '',
  ),
  'vod' => 
  array (
    'status' => '0',
    'url' => '',
    'link' => '',
  ),
);
$pause=array (
  'status' => '1',
  'pic' => 'https://ae01.alicdn.com/kf/H9eaa65d8fde748a4bdc554a02004c3437.png',
  'width' => '',
  'height' => '',
  'link' => 'https://madouym.com',
);
