-- -----------------------------
-- Table structure for `mac_actor`
-- -----------------------------
DROP TABLE IF EXISTS `mac_actor`;
CREATE TABLE `mac_actor` (
  `actor_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_id_1` smallint(6) unsigned NOT NULL DEFAULT '0',
  `actor_name` varchar(255) NOT NULL DEFAULT '',
  `actor_en` varchar(255) NOT NULL DEFAULT '',
  `actor_alias` varchar(255) NOT NULL DEFAULT '',
  `actor_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_letter` char(1) NOT NULL DEFAULT '',
  `actor_sex` char(1) NOT NULL DEFAULT '',
  `actor_color` varchar(6) NOT NULL DEFAULT '',
  `actor_pic` varchar(255) NOT NULL DEFAULT '',
  `actor_blurb` varchar(255) NOT NULL DEFAULT '',
  `actor_remarks` varchar(100) NOT NULL DEFAULT '',
  `actor_area` varchar(20) NOT NULL DEFAULT '',
  `actor_height` varchar(10) NOT NULL DEFAULT '',
  `actor_weight` varchar(10) NOT NULL DEFAULT '',
  `actor_birthday` varchar(10) NOT NULL DEFAULT '',
  `actor_birtharea` varchar(20) NOT NULL DEFAULT '',
  `actor_blood` varchar(10) NOT NULL DEFAULT '',
  `actor_starsign` varchar(10) NOT NULL DEFAULT '',
  `actor_school` varchar(20) NOT NULL DEFAULT '',
  `actor_works` varchar(255) NOT NULL DEFAULT '',
  `actor_tag` varchar(255) NOT NULL DEFAULT '',
  `actor_class` varchar(255) NOT NULL DEFAULT '',
  `actor_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `actor_time` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `actor_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `actor_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_score_num` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `actor_tpl` varchar(30) NOT NULL DEFAULT '',
  `actor_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `actor_content` text NOT NULL,
  PRIMARY KEY (`actor_id`),
  KEY `type_id` (`type_id`) USING BTREE,
  KEY `type_id_1` (`type_id_1`) USING BTREE,
  KEY `actor_name` (`actor_name`) USING BTREE,
  KEY `actor_en` (`actor_en`) USING BTREE,
  KEY `actor_letter` (`actor_letter`) USING BTREE,
  KEY `actor_level` (`actor_level`) USING BTREE,
  KEY `actor_time` (`actor_time`) USING BTREE,
  KEY `actor_time_add` (`actor_time_add`) USING BTREE,
  KEY `actor_sex` (`actor_sex`),
  KEY `actor_area` (`actor_area`),
  KEY `actor_up` (`actor_up`),
  KEY `actor_down` (`actor_down`),
  KEY `actor_tag` (`actor_tag`),
  KEY `actor_class` (`actor_class`),
  KEY `actor_score` (`actor_score`),
  KEY `actor_score_all` (`actor_score_all`),
  KEY `actor_score_num` (`actor_score_num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_annex`
-- -----------------------------
DROP TABLE IF EXISTS `mac_annex`;
CREATE TABLE `mac_annex` (
  `annex_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `annex_time` int(10) unsigned NOT NULL DEFAULT '0',
  `annex_file` varchar(255) NOT NULL DEFAULT '',
  `annex_size` int(10) unsigned NOT NULL DEFAULT '0',
  `annex_type` varchar(8) NOT NULL DEFAULT '',
  PRIMARY KEY (`annex_id`),
  KEY `annex_time` (`annex_time`),
  KEY `annex_file` (`annex_file`),
  KEY `annex_type` (`annex_type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_annex`
-- -----------------------------
INSERT INTO `mac_annex` VALUES ('1', '1632485372', 'upload/art/20210924-1/bf2f3af0fe67f81d4c14ea7839a2afbb.jpg', '14', 'image');

-- -----------------------------
-- Table structure for `mac_art`
-- -----------------------------
DROP TABLE IF EXISTS `mac_art`;
CREATE TABLE `mac_art` (
  `art_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_id_1` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `art_name` varchar(255) NOT NULL DEFAULT '',
  `art_sub` varchar(255) NOT NULL DEFAULT '',
  `art_en` varchar(255) NOT NULL DEFAULT '',
  `art_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_letter` char(1) NOT NULL DEFAULT '',
  `art_color` varchar(6) NOT NULL DEFAULT '',
  `art_from` varchar(30) NOT NULL DEFAULT '',
  `art_author` varchar(30) NOT NULL DEFAULT '',
  `art_tag` varchar(100) NOT NULL DEFAULT '',
  `art_class` varchar(255) NOT NULL DEFAULT '',
  `art_pic` varchar(255) NOT NULL DEFAULT '',
  `art_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `art_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `art_pic_screenshot` text,
  `art_blurb` varchar(255) NOT NULL DEFAULT '',
  `art_remarks` varchar(100) NOT NULL DEFAULT '',
  `art_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `art_tpl` varchar(30) NOT NULL DEFAULT '',
  `art_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `art_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `art_points_detail` smallint(6) unsigned NOT NULL DEFAULT '0',
  `art_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_time` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `art_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `art_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `art_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_score_num` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `art_rel_art` varchar(255) NOT NULL DEFAULT '',
  `art_rel_vod` varchar(255) NOT NULL DEFAULT '',
  `art_pwd` varchar(10) NOT NULL DEFAULT '',
  `art_pwd_url` varchar(255) NOT NULL DEFAULT '',
  `art_title` mediumtext NOT NULL,
  `art_note` mediumtext NOT NULL,
  `art_content` mediumtext NOT NULL,
  PRIMARY KEY (`art_id`),
  KEY `type_id` (`type_id`) USING BTREE,
  KEY `type_id_1` (`type_id_1`) USING BTREE,
  KEY `art_level` (`art_level`) USING BTREE,
  KEY `art_hits` (`art_hits`) USING BTREE,
  KEY `art_time` (`art_time`) USING BTREE,
  KEY `art_letter` (`art_letter`) USING BTREE,
  KEY `art_down` (`art_down`) USING BTREE,
  KEY `art_up` (`art_up`) USING BTREE,
  KEY `art_tag` (`art_tag`) USING BTREE,
  KEY `art_name` (`art_name`) USING BTREE,
  KEY `art_enn` (`art_en`) USING BTREE,
  KEY `art_hits_day` (`art_hits_day`) USING BTREE,
  KEY `art_hits_week` (`art_hits_week`) USING BTREE,
  KEY `art_hits_month` (`art_hits_month`) USING BTREE,
  KEY `art_time_add` (`art_time_add`) USING BTREE,
  KEY `art_time_make` (`art_time_make`) USING BTREE,
  KEY `art_lock` (`art_lock`),
  KEY `art_score` (`art_score`),
  KEY `art_score_all` (`art_score_all`),
  KEY `art_score_num` (`art_score_num`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_art`
-- -----------------------------
INSERT INTO `mac_art` VALUES ('1', '3', '0', '0', '广告招租中，期待与您的合作', '', 'guanggaozhaozuzhongqidaiyunindehezuo', '1', 'G', '', '', '', '', '', 'upload/art/20210924-1/bf2f3af0fe67f81d4c14ea7839a2afbb.jpg', '', '', '', '本站广告位长期招租中，详情联系客服咨询。', '', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1632485374', '1632473056', '0', '0', '0.0', '0', '0', '', '', '', '', '', '', '<p>本站广告位长期招租中，详情联系客服咨询。</p>');

-- -----------------------------
-- Table structure for `mac_card`
-- -----------------------------
DROP TABLE IF EXISTS `mac_card`;
CREATE TABLE `mac_card` (
  `card_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `card_no` varchar(16) NOT NULL DEFAULT '',
  `card_pwd` varchar(8) NOT NULL DEFAULT '',
  `card_money` smallint(6) unsigned NOT NULL DEFAULT '0',
  `card_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `card_use_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `card_sale_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `card_add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `card_use_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`card_id`),
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `card_add_time` (`card_add_time`) USING BTREE,
  KEY `card_use_time` (`card_use_time`) USING BTREE,
  KEY `card_no` (`card_no`),
  KEY `card_pwd` (`card_pwd`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_cash`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cash`;
CREATE TABLE `mac_cash` (
  `cash_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cash_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `cash_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cash_money` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `cash_bank_name` varchar(60) NOT NULL DEFAULT '',
  `cash_bank_no` varchar(30) NOT NULL DEFAULT '',
  `cash_payee_name` varchar(30) NOT NULL DEFAULT '',
  `cash_time` int(10) unsigned NOT NULL DEFAULT '0',
  `cash_time_audit` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cash_id`),
  KEY `user_id` (`user_id`),
  KEY `cash_status` (`cash_status`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_cj_content`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cj_content`;
CREATE TABLE `mac_cj_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nodeid` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `url` char(255) NOT NULL,
  `title` char(100) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nodeid` (`nodeid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_cj_history`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cj_history`;
CREATE TABLE `mac_cj_history` (
  `md5` char(32) NOT NULL,
  PRIMARY KEY (`md5`),
  KEY `md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_cj_node`
-- -----------------------------
DROP TABLE IF EXISTS `mac_cj_node`;
CREATE TABLE `mac_cj_node` (
  `nodeid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `sourcecharset` varchar(8) NOT NULL,
  `sourcetype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `urlpage` text NOT NULL,
  `pagesize_start` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pagesize_end` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `page_base` char(255) NOT NULL,
  `par_num` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `url_contain` char(100) NOT NULL,
  `url_except` char(100) NOT NULL,
  `url_start` char(100) NOT NULL DEFAULT '',
  `url_end` char(100) NOT NULL DEFAULT '',
  `title_rule` char(100) NOT NULL,
  `title_html_rule` text NOT NULL,
  `type_rule` char(100) NOT NULL,
  `type_html_rule` text NOT NULL,
  `content_rule` char(100) NOT NULL,
  `content_html_rule` text NOT NULL,
  `content_page_start` char(100) NOT NULL,
  `content_page_end` char(100) NOT NULL,
  `content_page_rule` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_page` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_nextpage` char(100) NOT NULL,
  `down_attachment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `watermark` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `coll_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `customize_config` text NOT NULL,
  `program_config` text NOT NULL,
  `mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `mac_collect`
-- -----------------------------
DROP TABLE IF EXISTS `mac_collect`;
CREATE TABLE `mac_collect` (
  `collect_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `collect_name` varchar(30) NOT NULL DEFAULT '',
  `collect_url` varchar(255) NOT NULL DEFAULT '',
  `collect_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `collect_mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `collect_appid` varchar(30) NOT NULL DEFAULT '',
  `collect_appkey` varchar(30) NOT NULL DEFAULT '',
  `collect_param` varchar(100) NOT NULL DEFAULT '',
  `collect_filter` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `collect_filter_from` varchar(255) NOT NULL DEFAULT '',
  `collect_opt` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`collect_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_comment`
-- -----------------------------
DROP TABLE IF EXISTS `mac_comment`;
CREATE TABLE `mac_comment` (
  `comment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comment_mid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `comment_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `comment_name` varchar(60) NOT NULL DEFAULT '',
  `comment_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_time` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_content` varchar(255) NOT NULL DEFAULT '',
  `comment_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_reply` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `comment_report` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `comment_mid` (`comment_mid`) USING BTREE,
  KEY `comment_rid` (`comment_rid`) USING BTREE,
  KEY `comment_time` (`comment_time`) USING BTREE,
  KEY `comment_pid` (`comment_pid`),
  KEY `user_id` (`user_id`),
  KEY `comment_reply` (`comment_reply`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_gbook`
-- -----------------------------
DROP TABLE IF EXISTS `mac_gbook`;
CREATE TABLE `mac_gbook` (
  `gbook_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gbook_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `gbook_name` varchar(60) NOT NULL DEFAULT '',
  `gbook_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_reply_time` int(10) unsigned NOT NULL DEFAULT '0',
  `gbook_content` varchar(255) NOT NULL DEFAULT '',
  `gbook_reply` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`gbook_id`),
  KEY `gbook_rid` (`gbook_rid`) USING BTREE,
  KEY `gbook_time` (`gbook_time`) USING BTREE,
  KEY `gbook_reply_time` (`gbook_reply_time`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `gbook_reply` (`gbook_reply`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_group`
-- -----------------------------
DROP TABLE IF EXISTS `mac_group`;
CREATE TABLE `mac_group` (
  `group_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) NOT NULL DEFAULT '',
  `group_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `group_type` text NOT NULL,
  `group_popedom` text NOT NULL,
  `group_points_day` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_week` smallint(6) NOT NULL DEFAULT '0',
  `group_points_month` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_year` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_points_free` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  KEY `group_status` (`group_status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_group`
-- -----------------------------
INSERT INTO `mac_group` VALUES ('1', '游客', '1', ',1,5,6,7,8,9,10,11,12,13,14,15,16,2,17,18,19,20,21,22,23,24,25,26,27,28,3,4,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"6\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"7\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"8\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"9\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"10\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"11\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"12\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"13\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"14\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"15\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"16\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"17\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"18\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"19\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"20\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"21\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"22\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"23\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"24\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"25\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"26\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"27\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"28\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\"},\"4\":{\"1\":\"1\",\"2\":\"2\"}}', '0', '0', '0', '0', '0');
INSERT INTO `mac_group` VALUES ('2', '默认会员', '1', ',1,5,6,7,8,9,10,11,12,13,14,15,16,2,17,18,19,20,21,22,23,24,25,26,27,28,3,4,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"6\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"7\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"8\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"9\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"10\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"11\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"12\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"13\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"14\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"15\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"16\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"17\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"18\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"19\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"20\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"21\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"22\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"23\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"24\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"25\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"26\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"27\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"28\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\"},\"4\":{\"1\":\"1\",\"2\":\"2\"}}', '0', '0', '0', '0', '0');
INSERT INTO `mac_group` VALUES ('3', 'VIP会员', '1', ',1,5,6,7,8,9,10,11,12,13,14,15,16,2,17,18,19,20,21,22,23,24,25,26,27,28,3,4,', '{\"1\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"6\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"7\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"8\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"9\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"10\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"11\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"12\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"13\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"14\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"15\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"16\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"17\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"18\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"19\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"20\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"21\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"22\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"23\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"24\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"25\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"26\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"27\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"28\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"3\":{\"1\":\"1\",\"2\":\"2\"},\"4\":{\"1\":\"1\",\"2\":\"2\"}}', '30', '50', '100', '200', '0');

-- -----------------------------
-- Table structure for `mac_link`
-- -----------------------------
DROP TABLE IF EXISTS `mac_link`;
CREATE TABLE `mac_link` (
  `link_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `link_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `link_name` varchar(60) NOT NULL DEFAULT '',
  `link_sort` smallint(6) NOT NULL DEFAULT '0',
  `link_add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `link_time` int(10) unsigned NOT NULL DEFAULT '0',
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_logo` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_sort` (`link_sort`) USING BTREE,
  KEY `link_type` (`link_type`) USING BTREE,
  KEY `link_add_time` (`link_add_time`),
  KEY `link_time` (`link_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_msg`
-- -----------------------------
DROP TABLE IF EXISTS `mac_msg`;
CREATE TABLE `mac_msg` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `msg_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `msg_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `msg_to` varchar(30) NOT NULL DEFAULT '',
  `msg_code` varchar(10) NOT NULL DEFAULT '',
  `msg_content` varchar(255) NOT NULL DEFAULT '',
  `msg_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`msg_id`),
  KEY `msg_code` (`msg_code`),
  KEY `msg_time` (`msg_time`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_order`
-- -----------------------------
DROP TABLE IF EXISTS `mac_order`;
CREATE TABLE `mac_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `order_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `order_code` varchar(30) NOT NULL DEFAULT '',
  `order_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `order_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_points` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `order_pay_type` varchar(10) NOT NULL DEFAULT '',
  `order_pay_time` int(10) unsigned NOT NULL DEFAULT '0',
  `order_remarks` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`order_id`),
  KEY `order_code` (`order_code`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `order_time` (`order_time`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_plog`
-- -----------------------------
DROP TABLE IF EXISTS `mac_plog`;
CREATE TABLE `mac_plog` (
  `plog_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_1` int(10) NOT NULL DEFAULT '0',
  `plog_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `plog_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `plog_time` int(10) unsigned NOT NULL DEFAULT '0',
  `plog_remarks` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`plog_id`),
  KEY `user_id` (`user_id`),
  KEY `plog_type` (`plog_type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_role`
-- -----------------------------
DROP TABLE IF EXISTS `mac_role`;
CREATE TABLE `mac_role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `role_name` varchar(255) NOT NULL DEFAULT '',
  `role_en` varchar(255) NOT NULL DEFAULT '',
  `role_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_letter` char(1) NOT NULL DEFAULT '',
  `role_color` varchar(6) NOT NULL DEFAULT '',
  `role_actor` varchar(255) NOT NULL DEFAULT '',
  `role_remarks` varchar(100) NOT NULL DEFAULT '',
  `role_pic` varchar(255) NOT NULL DEFAULT '',
  `role_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `role_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `role_time` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `role_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `role_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `role_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_score_num` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `role_tpl` varchar(30) NOT NULL DEFAULT '',
  `role_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `role_content` text NOT NULL,
  PRIMARY KEY (`role_id`),
  KEY `role_rid` (`role_rid`),
  KEY `role_name` (`role_name`),
  KEY `role_en` (`role_en`),
  KEY `role_letter` (`role_letter`),
  KEY `role_actor` (`role_actor`),
  KEY `role_level` (`role_level`),
  KEY `role_time` (`role_time`),
  KEY `role_time_add` (`role_time_add`),
  KEY `role_score` (`role_score`),
  KEY `role_score_all` (`role_score_all`),
  KEY `role_score_num` (`role_score_num`),
  KEY `role_up` (`role_up`),
  KEY `role_down` (`role_down`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_topic`
-- -----------------------------
DROP TABLE IF EXISTS `mac_topic`;
CREATE TABLE `mac_topic` (
  `topic_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `topic_name` varchar(255) NOT NULL DEFAULT '',
  `topic_en` varchar(255) NOT NULL DEFAULT '',
  `topic_sub` varchar(255) NOT NULL DEFAULT '',
  `topic_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `topic_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `topic_letter` char(1) NOT NULL DEFAULT '',
  `topic_color` varchar(6) NOT NULL DEFAULT '',
  `topic_tpl` varchar(30) NOT NULL DEFAULT '',
  `topic_type` varchar(255) NOT NULL DEFAULT '',
  `topic_pic` varchar(255) NOT NULL DEFAULT '',
  `topic_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `topic_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `topic_key` varchar(255) NOT NULL DEFAULT '',
  `topic_des` varchar(255) NOT NULL DEFAULT '',
  `topic_title` varchar(255) NOT NULL DEFAULT '',
  `topic_blurb` varchar(255) NOT NULL DEFAULT '',
  `topic_remarks` varchar(100) NOT NULL DEFAULT '',
  `topic_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `topic_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `topic_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_score_num` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `topic_time` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `topic_tag` varchar(255) NOT NULL DEFAULT '',
  `topic_rel_vod` text NOT NULL,
  `topic_rel_art` text NOT NULL,
  `topic_content` text NOT NULL,
  `topic_extend` text NOT NULL,
  PRIMARY KEY (`topic_id`),
  KEY `topic_sort` (`topic_sort`) USING BTREE,
  KEY `topic_level` (`topic_level`) USING BTREE,
  KEY `topic_score` (`topic_score`) USING BTREE,
  KEY `topic_score_all` (`topic_score_all`) USING BTREE,
  KEY `topic_score_num` (`topic_score_num`) USING BTREE,
  KEY `topic_hits` (`topic_hits`) USING BTREE,
  KEY `topic_hits_day` (`topic_hits_day`) USING BTREE,
  KEY `topic_hits_week` (`topic_hits_week`) USING BTREE,
  KEY `topic_hits_month` (`topic_hits_month`) USING BTREE,
  KEY `topic_time_add` (`topic_time_add`) USING BTREE,
  KEY `topic_time` (`topic_time`) USING BTREE,
  KEY `topic_time_hits` (`topic_time_hits`) USING BTREE,
  KEY `topic_name` (`topic_name`),
  KEY `topic_en` (`topic_en`),
  KEY `topic_up` (`topic_up`),
  KEY `topic_down` (`topic_down`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_type`
-- -----------------------------
DROP TABLE IF EXISTS `mac_type`;
CREATE TABLE `mac_type` (
  `type_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(60) NOT NULL DEFAULT '',
  `type_en` varchar(60) NOT NULL DEFAULT '',
  `type_sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_mid` smallint(6) unsigned NOT NULL DEFAULT '1',
  `type_pid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `type_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `type_tpl` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_list` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_detail` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_play` varchar(30) NOT NULL DEFAULT '',
  `type_tpl_down` varchar(30) NOT NULL DEFAULT '',
  `type_key` varchar(255) NOT NULL DEFAULT '',
  `type_des` varchar(255) NOT NULL DEFAULT '',
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_union` varchar(255) NOT NULL DEFAULT '',
  `type_extend` text NOT NULL,
  `type_logo` varchar(255) NOT NULL DEFAULT '',
  `type_pic` varchar(255) NOT NULL DEFAULT '',
  `type_jumpurl` varchar(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`type_id`),
  KEY `type_sort` (`type_sort`) USING BTREE,
  KEY `type_pid` (`type_pid`) USING BTREE,
  KEY `type_name` (`type_name`),
  KEY `type_en` (`type_en`),
  KEY `type_mid` (`type_mid`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_type`
-- -----------------------------
INSERT INTO `mac_type` VALUES ('1', '日韩', 'rihan', '1', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', 'iconfont icon-hanyu', 'https://cdn.jsdelivr.net/gh/madouym/images/117.png', '');
INSERT INTO `mac_type` VALUES ('2', '国产', 'guochan', '2', '1', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', 'iconfont icon-livetop', 'https://cdn.jsdelivr.net/gh/madouym/images/8.png', '');
INSERT INTO `mac_type` VALUES ('3', '站长说', 'zhanchangshuo', '3', '2', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\\u9009\\u79c0,\\u60c5\\u611f,\\u8bbf\\u8c08,\\u64ad\\u62a5,\\u65c5\\u6e38,\\u97f3\\u4e50,\\u7f8e\\u98df,\\u7eaa\\u5b9e,\\u66f2\\u827a,\\u751f\\u6d3b,\\u6e38\\u620f\\u4e92\\u52a8,\\u8d22\\u7ecf,\\u6c42\\u804c\",\"area\":\"\\u5185\\u5730,\\u6e2f\\u53f0,\\u65e5\\u97e9,\\u6b27\\u7f8e\",\"lang\":\"\\u56fd\\u8bed,\\u82f1\\u8bed,\\u7ca4\\u8bed,\\u95fd\\u5357\\u8bed,\\u97e9\\u8bed,\\u65e5\\u8bed,\\u5176\\u5b83\",\"year\":\"2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004\",\"star\":\"\\u4f55\\u7085,\\u6c6a\\u6db5,\\u8c22\\u5a1c,\\u5468\\u7acb\\u6ce2,\\u9648\\u9c81\\u8c6b,\\u5b5f\\u975e,\\u674e\\u9759,\\u6731\\u519b,\\u6731\\u4e39,\\u534e\\u5c11,\\u90ed\\u5fb7\\u7eb2,\\u6768\\u6f9c\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', '', '');
INSERT INTO `mac_type` VALUES ('4', '轮播', 'lunbo', '4', '11', '0', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/1.png', '');
INSERT INTO `mac_type` VALUES ('20', '子类16', '', '4', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/25.png', '');
INSERT INTO `mac_type` VALUES ('5', '子类1', '', '2', '1', '1', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/2.png', '');
INSERT INTO `mac_type` VALUES ('7', '子类3', '', '4', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/4.png', '');
INSERT INTO `mac_type` VALUES ('6', '子类2', '', '3', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/3.png', '');
INSERT INTO `mac_type` VALUES ('8', '子类4', '', '5', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/5.png', '');
INSERT INTO `mac_type` VALUES ('9', '子类5', '', '6', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/6.png', '');
INSERT INTO `mac_type` VALUES ('10', '子类6', '', '7', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/7.png', '');
INSERT INTO `mac_type` VALUES ('11', '子类7', '', '8', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/8.png', '');
INSERT INTO `mac_type` VALUES ('12', '子类8', '', '9', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/9.png', '');
INSERT INTO `mac_type` VALUES ('13', '子类9', '', '10', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/10.png', '');
INSERT INTO `mac_type` VALUES ('14', '子类10', '', '11', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/11.png', '');
INSERT INTO `mac_type` VALUES ('15', '子类11', '', '12', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/12.png', '');
INSERT INTO `mac_type` VALUES ('16', '子类12', '', '13', '1', '1', '1', 'type.html', 'show.html', 'detail.html', 'play.html', 'down.html', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/13.png', '');
INSERT INTO `mac_type` VALUES ('17', '子类13', '', '1', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/14.png', '');
INSERT INTO `mac_type` VALUES ('18', '子类14', '', '2', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/15.png', '');
INSERT INTO `mac_type` VALUES ('19', '子类15', '', '3', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/16.png', '');
INSERT INTO `mac_type` VALUES ('21', '子类17', '', '5', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/17.png', '');
INSERT INTO `mac_type` VALUES ('22', '子类18', '', '6', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/18.png', '');
INSERT INTO `mac_type` VALUES ('23', '子类19', '', '7', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/19.png', '');
INSERT INTO `mac_type` VALUES ('24', '子类20', '', '8', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/20.png', '');
INSERT INTO `mac_type` VALUES ('25', '子类21', '', '9', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/21.png', '');
INSERT INTO `mac_type` VALUES ('26', '子类22', '', '10', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/22.png', '');
INSERT INTO `mac_type` VALUES ('27', '子类23', '', '11', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/23.png', '');
INSERT INTO `mac_type` VALUES ('28', '子类24', '', '12', '1', '2', '1', 'type.html', 'show.html', 'detail.html', '', '', '', '', '', '', '{\"class\":\"\",\"area\":\"\",\"lang\":\"\",\"year\":\"\",\"star\":\"\",\"director\":\"\",\"state\":\"\",\"version\":\"\"}', '', 'https://cdn.jsdelivr.net/gh/madouym/images/24.png', '');

-- -----------------------------
-- Table structure for `mac_ulog`
-- -----------------------------
DROP TABLE IF EXISTS `mac_ulog`;
CREATE TABLE `mac_ulog` (
  `ulog_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `ulog_mid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ulog_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ulog_rid` int(10) unsigned NOT NULL DEFAULT '0',
  `ulog_sid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ulog_nid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `ulog_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `ulog_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ulog_id`),
  KEY `user_id` (`user_id`),
  KEY `ulog_mid` (`ulog_mid`),
  KEY `ulog_type` (`ulog_type`),
  KEY `ulog_rid` (`ulog_rid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_user`
-- -----------------------------
DROP TABLE IF EXISTS `mac_user`;
CREATE TABLE `mac_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_name` varchar(30) NOT NULL DEFAULT '',
  `user_pwd` varchar(32) NOT NULL DEFAULT '',
  `user_nick_name` varchar(30) NOT NULL DEFAULT '',
  `user_qq` varchar(16) NOT NULL DEFAULT '',
  `user_email` varchar(30) NOT NULL DEFAULT '',
  `user_phone` varchar(16) NOT NULL DEFAULT '',
  `user_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user_portrait` varchar(100) NOT NULL DEFAULT '',
  `user_portrait_thumb` varchar(100) NOT NULL DEFAULT '',
  `user_openid_qq` varchar(40) NOT NULL DEFAULT '',
  `user_openid_weixin` varchar(40) NOT NULL DEFAULT '',
  `user_question` varchar(255) NOT NULL DEFAULT '',
  `user_answer` varchar(255) NOT NULL DEFAULT '',
  `user_points` int(10) unsigned NOT NULL DEFAULT '0',
  `user_points_froze` int(10) unsigned NOT NULL DEFAULT '0',
  `user_reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_reg_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `user_last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_last_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `user_login_num` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_extend` smallint(6) unsigned NOT NULL DEFAULT '0',
  `user_random` varchar(32) NOT NULL DEFAULT '',
  `user_end_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_pid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_pid_2` int(10) unsigned NOT NULL DEFAULT '0',
  `user_pid_3` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  KEY `type_id` (`group_id`) USING BTREE,
  KEY `user_name` (`user_name`),
  KEY `user_reg_time` (`user_reg_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Table structure for `mac_visit`
-- -----------------------------
DROP TABLE IF EXISTS `mac_visit`;
CREATE TABLE `mac_visit` (
  `visit_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `visit_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `visit_ly` varchar(100) NOT NULL DEFAULT '',
  `visit_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`visit_id`),
  KEY `user_id` (`user_id`),
  KEY `visit_time` (`visit_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `mac_vod`
-- -----------------------------
DROP TABLE IF EXISTS `mac_vod`;
CREATE TABLE `mac_vod` (
  `vod_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(6) NOT NULL DEFAULT '0',
  `type_id_1` smallint(6) unsigned NOT NULL DEFAULT '0',
  `group_id` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_name` varchar(255) NOT NULL DEFAULT '',
  `vod_sub` varchar(255) NOT NULL DEFAULT '',
  `vod_en` varchar(255) NOT NULL DEFAULT '',
  `vod_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_letter` char(1) NOT NULL DEFAULT '',
  `vod_color` varchar(6) NOT NULL DEFAULT '',
  `vod_tag` varchar(100) NOT NULL DEFAULT '',
  `vod_class` varchar(255) NOT NULL DEFAULT '',
  `vod_pic` varchar(255) NOT NULL DEFAULT '',
  `vod_pic_thumb` varchar(255) NOT NULL DEFAULT '',
  `vod_pic_slide` varchar(255) NOT NULL DEFAULT '',
  `vod_pic_screenshot` text,
  `vod_actor` varchar(255) NOT NULL DEFAULT '',
  `vod_director` varchar(255) NOT NULL DEFAULT '',
  `vod_writer` varchar(100) NOT NULL DEFAULT '',
  `vod_behind` varchar(100) NOT NULL DEFAULT '',
  `vod_blurb` varchar(255) NOT NULL DEFAULT '',
  `vod_remarks` varchar(100) NOT NULL DEFAULT '',
  `vod_pubdate` varchar(100) NOT NULL DEFAULT '',
  `vod_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_serial` varchar(20) NOT NULL DEFAULT '0',
  `vod_tv` varchar(30) NOT NULL DEFAULT '',
  `vod_weekday` varchar(30) NOT NULL DEFAULT '',
  `vod_area` varchar(20) NOT NULL DEFAULT '',
  `vod_lang` varchar(10) NOT NULL DEFAULT '',
  `vod_year` varchar(10) NOT NULL DEFAULT '',
  `vod_version` varchar(30) NOT NULL DEFAULT '',
  `vod_state` varchar(30) NOT NULL DEFAULT '',
  `vod_author` varchar(60) NOT NULL DEFAULT '',
  `vod_jumpurl` varchar(150) NOT NULL DEFAULT '',
  `vod_tpl` varchar(30) NOT NULL DEFAULT '',
  `vod_tpl_play` varchar(30) NOT NULL DEFAULT '',
  `vod_tpl_down` varchar(30) NOT NULL DEFAULT '',
  `vod_isend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_points` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_points_play` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_points_down` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_duration` varchar(10) NOT NULL DEFAULT '',
  `vod_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `vod_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_score_num` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `vod_time` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_trysee` smallint(6) unsigned NOT NULL DEFAULT '0',
  `vod_douban_id` int(10) unsigned NOT NULL DEFAULT '0',
  `vod_douban_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `vod_reurl` varchar(255) NOT NULL DEFAULT '',
  `vod_rel_vod` varchar(255) NOT NULL DEFAULT '',
  `vod_rel_art` varchar(255) NOT NULL DEFAULT '',
  `vod_pwd` varchar(10) NOT NULL DEFAULT '',
  `vod_pwd_url` varchar(255) NOT NULL DEFAULT '',
  `vod_pwd_play` varchar(10) NOT NULL DEFAULT '',
  `vod_pwd_play_url` varchar(255) NOT NULL DEFAULT '',
  `vod_pwd_down` varchar(10) NOT NULL DEFAULT '',
  `vod_pwd_down_url` varchar(255) NOT NULL DEFAULT '',
  `vod_content` text NOT NULL,
  `vod_play_from` varchar(255) NOT NULL DEFAULT '',
  `vod_play_server` varchar(255) NOT NULL DEFAULT '',
  `vod_play_note` varchar(255) NOT NULL DEFAULT '',
  `vod_play_url` mediumtext NOT NULL,
  `vod_down_from` varchar(255) NOT NULL DEFAULT '',
  `vod_down_server` varchar(255) NOT NULL DEFAULT '',
  `vod_down_note` varchar(255) NOT NULL DEFAULT '',
  `vod_down_url` mediumtext NOT NULL,
  `vod_plot` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vod_plot_name` mediumtext NOT NULL,
  `vod_plot_detail` mediumtext NOT NULL,
  PRIMARY KEY (`vod_id`),
  KEY `type_id` (`type_id`) USING BTREE,
  KEY `type_id_1` (`type_id_1`) USING BTREE,
  KEY `vod_level` (`vod_level`) USING BTREE,
  KEY `vod_hits` (`vod_hits`) USING BTREE,
  KEY `vod_letter` (`vod_letter`) USING BTREE,
  KEY `vod_name` (`vod_name`) USING BTREE,
  KEY `vod_year` (`vod_year`) USING BTREE,
  KEY `vod_area` (`vod_area`) USING BTREE,
  KEY `vod_lang` (`vod_lang`) USING BTREE,
  KEY `vod_tag` (`vod_tag`) USING BTREE,
  KEY `vod_class` (`vod_class`) USING BTREE,
  KEY `vod_lock` (`vod_lock`) USING BTREE,
  KEY `vod_up` (`vod_up`) USING BTREE,
  KEY `vod_down` (`vod_down`) USING BTREE,
  KEY `vod_en` (`vod_en`) USING BTREE,
  KEY `vod_hits_day` (`vod_hits_day`) USING BTREE,
  KEY `vod_hits_week` (`vod_hits_week`) USING BTREE,
  KEY `vod_hits_month` (`vod_hits_month`) USING BTREE,
  KEY `vod_plot` (`vod_plot`) USING BTREE,
  KEY `vod_points_play` (`vod_points_play`) USING BTREE,
  KEY `vod_points_down` (`vod_points_down`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE,
  KEY `vod_time_add` (`vod_time_add`) USING BTREE,
  KEY `vod_time` (`vod_time`) USING BTREE,
  KEY `vod_time_make` (`vod_time_make`) USING BTREE,
  KEY `vod_actor` (`vod_actor`) USING BTREE,
  KEY `vod_director` (`vod_director`) USING BTREE,
  KEY `vod_score_all` (`vod_score_all`) USING BTREE,
  KEY `vod_score_num` (`vod_score_num`) USING BTREE,
  KEY `vod_total` (`vod_total`) USING BTREE,
  KEY `vod_score` (`vod_score`) USING BTREE,
  KEY `vod_version` (`vod_version`),
  KEY `vod_state` (`vod_state`),
  KEY `vod_isend` (`vod_isend`)
) ENGINE=MyISAM AUTO_INCREMENT=178 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_vod`
-- -----------------------------
INSERT INTO `mac_vod` VALUES ('1', '20', '2', '0', '二次元动漫漂亮小姐姐177', '', 'erciyuandongmanpiaoliangxiaojiejie177', '1', 'E', '', '二次元动漫漂亮小姐姐177,二次,次元,动漫,漂亮,姐姐,177,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/177.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '10', '10', '0', '942', '384', '750', '935', '04:51', '562', '592', '7.0', '2499', '357', '1632474918', '1632474918', '1631752815', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('2', '20', '2', '0', '二次元动漫漂亮小姐姐176', '', 'erciyuandongmanpiaoliangxiaojiejie176', '1', 'E', '', '二次元动漫漂亮小姐姐176,二次,次元,动漫,漂亮,姐姐,176,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/176.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '71', '179', '9', '408', '04:51', '698', '167', '3.0', '1890', '630', '1632474919', '1632474919', '1632318152', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('3', '20', '2', '0', '二次元动漫漂亮小姐姐175', '', 'erciyuandongmanpiaoliangxiaojiejie175', '1', 'E', '', '二次元动漫漂亮小姐姐175,二次,次元,动漫,漂亮,姐姐,175,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/175.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '217', '243', '909', '351', '04:51', '867', '454', '7.0', '1302', '186', '1632474919', '1632474919', '1632388786', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('4', '20', '2', '0', '二次元动漫漂亮小姐姐174', '', 'erciyuandongmanpiaoliangxiaojiejie174', '1', 'E', '', '二次元动漫漂亮小姐姐174,二次,次元,动漫,漂亮,姐姐,174,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/174.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '6', '710', '515', '937', '04:51', '968', '949', '1.0', '507', '507', '1632474919', '1632474919', '1632466146', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('5', '8', '1', '0', '二次元动漫漂亮小姐姐173', '', 'erciyuandongmanpiaoliangxiaojiejie173', '1', 'E', '', '', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/173.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '108', '676', '44', '254', '04:51', '395', '967', '4.0', '2848', '712', '1632474919', '1632474919', '1632407285', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('6', '8', '1', '0', '二次元动漫漂亮小姐姐172', '', 'erciyuandongmanpiaoliangxiaojiejie172', '1', 'E', '', '二次元动漫漂亮小姐姐172,二次,次元,动漫,漂亮,姐姐,172,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/172.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '403', '367', '352', '782', '04:51', '530', '47', '10.0', '3380', '338', '1632474919', '1632474919', '1632388778', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('7', '9', '1', '0', '二次元动漫漂亮小姐姐171', '', 'erciyuandongmanpiaoliangxiaojiejie171', '1', 'E', '', '二次元动漫漂亮小姐姐171,二次,次元,动漫,漂亮,姐姐,171,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/171.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '244', '113', '796', '433', '04:51', '45', '410', '4.0', '1040', '260', '1632474919', '1632474919', '1631985215', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('8', '9', '1', '0', '二次元动漫漂亮小姐姐170', '', 'erciyuandongmanpiaoliangxiaojiejie170', '1', 'E', '', '二次元动漫漂亮小姐姐170,二次,次元,动漫,漂亮,姐姐,170,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/170.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '120', '297', '729', '562', '04:51', '163', '949', '8.0', '2600', '325', '1632474919', '1632474919', '1632316367', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('9', '10', '1', '0', '二次元动漫漂亮小姐姐169', '', 'erciyuandongmanpiaoliangxiaojiejie169', '1', 'E', '', '二次元动漫漂亮小姐姐169,二次,次元,动漫,漂亮,姐姐,169,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/169.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '447', '995', '263', '741', '04:51', '229', '266', '5.0', '2240', '448', '1632474919', '1632474919', '1630671803', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('10', '10', '1', '0', '二次元动漫漂亮小姐姐168', '', 'erciyuandongmanpiaoliangxiaojiejie168', '1', 'E', '', '二次元动漫漂亮小姐姐168,二次,次元,动漫,漂亮,姐姐,168,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/168.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '403', '313', '134', '853', '04:51', '769', '8', '4.0', '2500', '625', '1632474919', '1632474919', '1632369319', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('11', '11', '1', '0', '二次元动漫漂亮小姐姐167', '', 'erciyuandongmanpiaoliangxiaojiejie167', '1', 'E', '', '二次元动漫漂亮小姐姐167,二次,次元,动漫,漂亮,姐姐,167,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/167.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '351', '823', '356', '864', '04:51', '26', '270', '2.0', '458', '229', '1632474919', '1632474919', '1632042578', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('12', '11', '1', '0', '二次元动漫漂亮小姐姐166', '', 'erciyuandongmanpiaoliangxiaojiejie166', '1', 'E', '', '二次元动漫漂亮小姐姐166,二次,次元,动漫,漂亮,姐姐,166,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/166.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '492', '235', '327', '355', '04:51', '947', '303', '4.0', '340', '85', '1632474919', '1632474919', '1632411676', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('13', '16', '2', '0', '二次元动漫漂亮小姐姐165', '', 'erciyuandongmanpiaoliangxiaojiejie165', '1', 'E', '', '二次元动漫漂亮小姐姐165,二次,次元,动漫,漂亮,姐姐,165,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/165.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '707', '681', '438', '639', '04:51', '187', '353', '5.0', '2340', '468', '1632474919', '1632474919', '1632060251', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('14', '16', '2', '0', '二次元动漫漂亮小姐姐164', '', 'erciyuandongmanpiaoliangxiaojiejie164', '1', 'E', '', '二次元动漫漂亮小姐姐164,二次,次元,动漫,漂亮,姐姐,164,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/164.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '987', '251', '343', '104', '04:51', '609', '682', '9.0', '450', '50', '1632474919', '1632474919', '1631297646', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('15', '17', '2', '0', '二次元动漫漂亮小姐姐163', '', 'erciyuandongmanpiaoliangxiaojiejie163', '1', 'E', '', '二次元动漫漂亮小姐姐163,二次,次元,动漫,漂亮,姐姐,163,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/163.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '338', '823', '231', '245', '04:51', '6', '899', '7.0', '3066', '438', '1632474919', '1632474919', '1631507403', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('16', '17', '2', '0', '二次元动漫漂亮小姐姐162', '', 'erciyuandongmanpiaoliangxiaojiejie162', '1', 'E', '', '二次元动漫漂亮小姐姐162,二次,次元,动漫,漂亮,姐姐,162,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/162.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '834', '581', '223', '810', '04:51', '190', '484', '7.0', '5180', '740', '1632474919', '1632474919', '1632197124', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('17', '18', '2', '0', '二次元动漫漂亮小姐姐161', '', 'erciyuandongmanpiaoliangxiaojiejie161', '1', 'E', '', '二次元动漫漂亮小姐姐161,二次,次元,动漫,漂亮,姐姐,161,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/161.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '827', '195', '817', '867', '04:51', '431', '70', '7.0', '4375', '625', '1632474919', '1632474919', '1632335106', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('18', '18', '2', '0', '二次元动漫漂亮小姐姐160', '', 'erciyuandongmanpiaoliangxiaojiejie160', '1', 'E', '', '二次元动漫漂亮小姐姐160,二次,次元,动漫,漂亮,姐姐,160,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/160.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '836', '285', '724', '314', '04:51', '987', '538', '7.0', '2086', '298', '1632474919', '1632474919', '1631336472', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('19', '20', '2', '0', '二次元动漫漂亮小姐姐159', '', 'erciyuandongmanpiaoliangxiaojiejie159', '1', 'E', '', '二次元动漫漂亮小姐姐159,二次,次元,动漫,漂亮,姐姐,159,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/159.png', '', '', '', '乐正绫', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '216', '644', '457', '279', '04:51', '991', '624', '2.0', '1302', '651', '1632474919', '1632474919', '1632416411', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('20', '20', '2', '0', '二次元动漫漂亮小姐姐158', '', 'erciyuandongmanpiaoliangxiaojiejie158', '1', 'E', '', '二次元动漫漂亮小姐姐158,二次,次元,动漫,漂亮,姐姐,158,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/158.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '280', '344', '883', '91', '04:51', '469', '406', '9.0', '6075', '675', '1632474919', '1632474919', '1631157572', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('21', '20', '2', '0', '二次元动漫漂亮小姐姐157', '', 'erciyuandongmanpiaoliangxiaojiejie157', '1', 'E', '', '二次元动漫漂亮小姐姐157,二次,次元,动漫,漂亮,姐姐,157,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/157.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '227', '749', '157', '898', '04:51', '660', '223', '1.0', '795', '795', '1632474922', '1632474922', '1632447884', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('22', '20', '2', '0', '二次元动漫漂亮小姐姐156', '', 'erciyuandongmanpiaoliangxiaojiejie156', '1', 'E', '', '二次元动漫漂亮小姐姐156,二次,次元,动漫,漂亮,姐姐,156,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/156.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '665', '952', '846', '3', '04:51', '357', '163', '4.0', '1440', '360', '1632474922', '1632474922', '1632416403', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('23', '20', '2', '0', '二次元动漫漂亮小姐姐154', '', 'erciyuandongmanpiaoliangxiaojiejie154', '1', 'E', '', '二次元动漫漂亮小姐姐154,二次,次元,动漫,漂亮,姐姐,154,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/154.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '248', '276', '492', '50', '04:51', '585', '142', '1.0', '651', '651', '1632474922', '1632474922', '1632366017', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('24', '20', '2', '0', '二次元动漫漂亮小姐姐155', '', 'erciyuandongmanpiaoliangxiaojiejie155', '1', 'E', '', '二次元动漫漂亮小姐姐155,二次,次元,动漫,漂亮,姐姐,155,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/155.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '595', '736', '609', '535', '04:51', '651', '421', '9.0', '6516', '724', '1632474922', '1632474922', '1632059170', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('25', '20', '2', '0', '二次元动漫漂亮小姐姐152', '', 'erciyuandongmanpiaoliangxiaojiejie152', '1', 'E', '', '二次元动漫漂亮小姐姐152,二次,次元,动漫,漂亮,姐姐,152,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/152.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '598', '331', '74', '254', '04:51', '616', '907', '10.0', '4720', '472', '1632474922', '1632474922', '1631755219', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('26', '20', '2', '0', '二次元动漫漂亮小姐姐153', '', 'erciyuandongmanpiaoliangxiaojiejie153', '1', 'E', '', '二次元动漫漂亮小姐姐153,二次,次元,动漫,漂亮,姐姐,153,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/153.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '558', '388', '373', '709', '04:51', '481', '79', '4.0', '2492', '623', '1632474922', '1632474922', '1631975503', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('27', '20', '2', '0', '二次元动漫漂亮小姐姐150', '', 'erciyuandongmanpiaoliangxiaojiejie150', '1', 'E', '', '二次元动漫漂亮小姐姐150,二次,次元,动漫,漂亮,姐姐,150,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/150.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '254', '622', '25', '975', '04:51', '104', '575', '3.0', '2541', '847', '1632474922', '1632474922', '1630758431', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('28', '20', '2', '0', '二次元动漫漂亮小姐姐151', '', 'erciyuandongmanpiaoliangxiaojiejie151', '1', 'E', '', '二次元动漫漂亮小姐姐151,二次,次元,动漫,漂亮,姐姐,151,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/151.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '710', '420', '284', '949', '04:51', '300', '732', '10.0', '5720', '572', '1632474922', '1632474922', '1631328515', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('29', '20', '2', '0', '二次元动漫漂亮小姐姐149', '', 'erciyuandongmanpiaoliangxiaojiejie149', '1', 'E', '', '二次元动漫漂亮小姐姐149,二次,次元,动漫,漂亮,姐姐,149,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/149.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '274', '54', '433', '92', '04:51', '267', '514', '1.0', '201', '201', '1632474922', '1632474922', '1631328519', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('30', '20', '2', '0', '二次元动漫漂亮小姐姐147', '', 'erciyuandongmanpiaoliangxiaojiejie147', '1', 'E', '', '二次元动漫漂亮小姐姐147,二次,次元,动漫,漂亮,姐姐,147,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/147.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '826', '969', '685', '200', '04:51', '647', '240', '5.0', '1940', '388', '1632474922', '1632474922', '1632369348', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('31', '20', '2', '0', '二次元动漫漂亮小姐姐148', '', 'erciyuandongmanpiaoliangxiaojiejie148', '1', 'E', '', '二次元动漫漂亮小姐姐148,二次,次元,动漫,漂亮,姐姐,148,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/148.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '597', '38', '185', '39', '04:51', '295', '95', '1.0', '512', '512', '1632474922', '1632474922', '1632017472', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('32', '20', '2', '0', '二次元动漫漂亮小姐姐145', '', 'erciyuandongmanpiaoliangxiaojiejie145', '1', 'E', '', '二次元动漫漂亮小姐姐145,二次,次元,动漫,漂亮,姐姐,145,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/145.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '77', '584', '29', '983', '04:51', '901', '342', '4.0', '2172', '543', '1632474922', '1632474922', '1632197129', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('33', '20', '2', '0', '二次元动漫漂亮小姐姐146', '', 'erciyuandongmanpiaoliangxiaojiejie146', '1', 'E', '', '二次元动漫漂亮小姐姐146,二次,次元,动漫,漂亮,姐姐,146,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/146.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '417', '458', '276', '326', '04:51', '893', '353', '10.0', '7180', '718', '1632474922', '1632474922', '1632041800', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('34', '20', '2', '0', '二次元动漫漂亮小姐姐144', '', 'erciyuandongmanpiaoliangxiaojiejie144', '1', 'E', '', '二次元动漫漂亮小姐姐144,二次,次元,动漫,漂亮,姐姐,144,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/144.png', '', '', '', '嫣汐', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '812', '954', '111', '566', '04:51', '809', '721', '1.0', '888', '888', '1632474922', '1632474922', '1632163214', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('35', '19', '2', '0', '二次元动漫漂亮小姐姐142', '', 'erciyuandongmanpiaoliangxiaojiejie142', '1', 'E', '', '二次元动漫漂亮小姐姐142,二次,次元,动漫,漂亮,姐姐,142,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/142.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '267', '505', '693', '473', '04:51', '38', '706', '6.0', '4602', '767', '1632474923', '1632474923', '1632081741', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('36', '19', '2', '0', '二次元动漫漂亮小姐姐143', '', 'erciyuandongmanpiaoliangxiaojiejie143', '1', 'E', '', '二次元动漫漂亮小姐姐143,二次,次元,动漫,漂亮,姐姐,143,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/143.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '955', '217', '259', '546', '04:51', '8', '760', '9.0', '8685', '965', '1632474923', '1632474923', '1632202867', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('37', '19', '2', '0', '二次元动漫漂亮小姐姐141', '', 'erciyuandongmanpiaoliangxiaojiejie141', '1', 'E', '', '二次元动漫漂亮小姐姐141,二次,次元,动漫,漂亮,姐姐,141,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/141.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '610', '837', '24', '546', '04:51', '286', '313', '1.0', '907', '907', '1632474923', '1632474923', '1631476005', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('38', '20', '2', '0', '二次元动漫漂亮小姐姐139', '', 'erciyuandongmanpiaoliangxiaojiejie139', '1', 'E', '', '二次元动漫漂亮小姐姐139,二次,次元,动漫,漂亮,姐姐,139,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/139.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '596', '337', '744', '544', '04:51', '373', '760', '7.0', '1176', '168', '1632474923', '1632474923', '1631972229', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('39', '20', '2', '0', '二次元动漫漂亮小姐姐140', '', 'erciyuandongmanpiaoliangxiaojiejie140', '1', 'E', '', '二次元动漫漂亮小姐姐140,二次,次元,动漫,漂亮,姐姐,140,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/140.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '870', '388', '173', '175', '04:51', '765', '499', '10.0', '5890', '589', '1632474923', '1632474923', '1630838570', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('40', '20', '2', '0', '二次元动漫漂亮小姐姐138', '', 'erciyuandongmanpiaoliangxiaojiejie138', '1', 'E', '', '二次元动漫漂亮小姐姐138,二次,次元,动漫,漂亮,姐姐,138,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/138.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '361', '181', '560', '611', '04:51', '783', '441', '2.0', '858', '429', '1632474923', '1632474923', '1630672140', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('41', '18', '2', '0', '二次元动漫漂亮小姐姐136', '', 'erciyuandongmanpiaoliangxiaojiejie136', '1', 'E', '', '二次元动漫漂亮小姐姐136,二次,次元,动漫,漂亮,姐姐,136,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/136.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '613', '832', '657', '79', '04:51', '342', '878', '4.0', '3024', '756', '1632474926', '1632474926', '1630325330', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('42', '18', '2', '0', '二次元动漫漂亮小姐姐137', '', 'erciyuandongmanpiaoliangxiaojiejie137', '1', 'E', '', '二次元动漫漂亮小姐姐137,二次,次元,动漫,漂亮,姐姐,137,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/137.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '200', '15', '264', '799', '04:51', '568', '418', '6.0', '402', '67', '1632474926', '1632474926', '1630338363', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('43', '18', '2', '0', '二次元动漫漂亮小姐姐135', '', 'erciyuandongmanpiaoliangxiaojiejie135', '1', 'E', '', '二次元动漫漂亮小姐姐135,二次,次元,动漫,漂亮,姐姐,135,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/135.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '898', '376', '812', '534', '04:51', '589', '303', '5.0', '3505', '701', '1632474926', '1632474926', '1630777924', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('44', '19', '2', '0', '二次元动漫漂亮小姐姐133', '', 'erciyuandongmanpiaoliangxiaojiejie133', '1', 'E', '', '二次元动漫漂亮小姐姐133,二次,次元,动漫,漂亮,姐姐,133,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/133.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '943', '494', '78', '85', '04:51', '312', '238', '6.0', '1338', '223', '1632474926', '1632474926', '1627884839', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('45', '19', '2', '0', '二次元动漫漂亮小姐姐134', '', 'erciyuandongmanpiaoliangxiaojiejie134', '1', 'E', '', '二次元动漫漂亮小姐姐134,二次,次元,动漫,漂亮,姐姐,134,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/134.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '70', '264', '397', '860', '04:51', '883', '809', '5.0', '3455', '691', '1632474926', '1632474926', '1631803525', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('46', '19', '2', '0', '二次元动漫漂亮小姐姐132', '', 'erciyuandongmanpiaoliangxiaojiejie132', '1', 'E', '', '二次元动漫漂亮小姐姐132,二次,次元,动漫,漂亮,姐姐,132,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/132.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '340', '854', '255', '286', '04:51', '305', '217', '10.0', '1320', '132', '1632474926', '1632474926', '1631235319', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('47', '19', '2', '0', '二次元动漫漂亮小姐姐130', '', 'erciyuandongmanpiaoliangxiaojiejie130', '1', 'E', '', '二次元动漫漂亮小姐姐130,二次,次元,动漫,漂亮,姐姐,130,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/130.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '262', '226', '111', '751', '04:51', '679', '132', '10.0', '2700', '270', '1632474926', '1632474926', '1631200674', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('48', '19', '2', '0', '二次元动漫漂亮小姐姐131', '', 'erciyuandongmanpiaoliangxiaojiejie131', '1', 'E', '', '二次元动漫漂亮小姐姐131,二次,次元,动漫,漂亮,姐姐,131,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/131.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '513', '144', '428', '360', '04:51', '406', '821', '7.0', '5117', '731', '1632474926', '1632474926', '1632197145', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('49', '19', '2', '0', '二次元动漫漂亮小姐姐128', '', 'erciyuandongmanpiaoliangxiaojiejie128', '1', 'E', '', '二次元动漫漂亮小姐姐128,二次,次元,动漫,漂亮,姐姐,128,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/128.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '245', '959', '158', '679', '04:51', '491', '873', '5.0', '2400', '480', '1632474926', '1632474926', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('50', '19', '2', '0', '二次元动漫漂亮小姐姐129', '', 'erciyuandongmanpiaoliangxiaojiejie129', '1', 'E', '', '二次元动漫漂亮小姐姐129,二次,次元,动漫,漂亮,姐姐,129,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/129.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '653', '393', '395', '849', '04:51', '983', '379', '4.0', '1788', '447', '1632474926', '1632474926', '1627886648', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('51', '19', '2', '0', '二次元动漫漂亮小姐姐127', '', 'erciyuandongmanpiaoliangxiaojiejie127', '1', 'E', '', '二次元动漫漂亮小姐姐127,二次,次元,动漫,漂亮,姐姐,127,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/127.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '71', '512', '505', '719', '04:51', '729', '154', '10.0', '6110', '611', '1632474926', '1632474926', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('52', '19', '2', '0', '二次元动漫漂亮小姐姐126', '', 'erciyuandongmanpiaoliangxiaojiejie126', '1', 'E', '', '二次元动漫漂亮小姐姐126,二次,次元,动漫,漂亮,姐姐,126,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/126.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '27', '904', '243', '646', '04:51', '398', '267', '2.0', '1478', '739', '1632474926', '1632474926', '1631006892', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('53', '19', '2', '0', '二次元动漫漂亮小姐姐125', '', 'erciyuandongmanpiaoliangxiaojiejie125', '1', 'E', '', '二次元动漫漂亮小姐姐125,二次,次元,动漫,漂亮,姐姐,125,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/125.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '769', '464', '909', '29', '04:51', '505', '571', '9.0', '4149', '461', '1632474926', '1632474926', '1632448478', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('54', '19', '2', '0', '二次元动漫漂亮小姐姐123', '', 'erciyuandongmanpiaoliangxiaojiejie123', '1', 'E', '', '二次元动漫漂亮小姐姐123,二次,次元,动漫,漂亮,姐姐,123,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/123.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '269', '369', '9', '72', '04:51', '493', '767', '6.0', '4428', '738', '1632474926', '1632474926', '1632152436', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('55', '19', '2', '0', '二次元动漫漂亮小姐姐124', '', 'erciyuandongmanpiaoliangxiaojiejie124', '1', 'E', '', '二次元动漫漂亮小姐姐124,二次,次元,动漫,漂亮,姐姐,124,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/124.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '263', '596', '350', '298', '04:51', '805', '231', '5.0', '3790', '758', '1632474926', '1632474926', '1632407556', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('56', '19', '2', '0', '二次元动漫漂亮小姐姐122', '', 'erciyuandongmanpiaoliangxiaojiejie122', '1', 'E', '', '二次元动漫漂亮小姐姐122,二次,次元,动漫,漂亮,姐姐,122,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/122.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '768', '864', '63', '94', '04:51', '154', '781', '9.0', '1530', '170', '1632474926', '1632474926', '1632098967', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('57', '19', '2', '0', '二次元动漫漂亮小姐姐121', '', 'erciyuandongmanpiaoliangxiaojiejie121', '1', 'E', '', '二次元动漫漂亮小姐姐121,二次,次元,动漫,漂亮,姐姐,121,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/121.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '74', '724', '411', '240', '04:51', '88', '836', '1.0', '456', '456', '1632474926', '1632474926', '1632413984', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('58', '19', '2', '0', '二次元动漫漂亮小姐姐120', '', 'erciyuandongmanpiaoliangxiaojiejie120', '1', 'E', '', '二次元动漫漂亮小姐姐120,二次,次元,动漫,漂亮,姐姐,120,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/120.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '311', '187', '556', '328', '04:51', '66', '24', '4.0', '3224', '806', '1632474926', '1632474926', '1632407302', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('59', '19', '2', '0', '二次元动漫漂亮小姐姐119', '', 'erciyuandongmanpiaoliangxiaojiejie119', '1', 'E', '', '二次元动漫漂亮小姐姐119,二次,次元,动漫,漂亮,姐姐,119,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/119.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '196', '995', '494', '953', '04:51', '207', '778', '7.0', '4914', '702', '1632474926', '1632474926', '1630724070', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('60', '19', '2', '0', '二次元动漫漂亮小姐姐118', '', 'erciyuandongmanpiaoliangxiaojiejie118', '1', 'E', '', '二次元动漫漂亮小姐姐118,二次,次元,动漫,漂亮,姐姐,118,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/118.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '910', '54', '774', '479', '04:51', '204', '384', '4.0', '2752', '688', '1632474926', '1632474926', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('61', '17', '2', '0', '二次元动漫漂亮小姐姐117', '', 'erciyuandongmanpiaoliangxiaojiejie117', '1', 'E', '', '二次元动漫漂亮小姐姐117,二次,次元,动漫,漂亮,姐姐,117,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/117.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '9', '0', '0', '0', '0', '87', '852', '442', '991', '04:51', '454', '969', '9.0', '4095', '455', '1632474930', '1632474930', '1630347407', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('62', '17', '2', '0', '二次元动漫漂亮小姐姐115', '', 'erciyuandongmanpiaoliangxiaojiejie115', '1', 'E', '', '二次元动漫漂亮小姐姐115,二次,次元,动漫,漂亮,姐姐,115,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/115.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '666', '770', '103', '739', '04:51', '671', '137', '9.0', '4500', '500', '1632474930', '1632474930', '1610554738', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('63', '17', '2', '0', '二次元动漫漂亮小姐姐116', '', 'erciyuandongmanpiaoliangxiaojiejie116', '1', 'E', '', '二次元动漫漂亮小姐姐116,二次,次元,动漫,漂亮,姐姐,116,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/116.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '228', '340', '914', '156', '04:51', '414', '222', '6.0', '2550', '425', '1632474930', '1632474930', '1629664232', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('64', '18', '2', '0', '二次元动漫漂亮小姐姐114', '', 'erciyuandongmanpiaoliangxiaojiejie114', '1', 'E', '', '二次元动漫漂亮小姐姐114,二次,次元,动漫,漂亮,姐姐,114,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/114.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '925', '167', '857', '24', '04:51', '5', '932', '4.0', '1416', '354', '1632474930', '1632474930', '1632197150', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('65', '18', '2', '0', '二次元动漫漂亮小姐姐113', '', 'erciyuandongmanpiaoliangxiaojiejie113', '1', 'E', '', '二次元动漫漂亮小姐姐113,二次,次元,动漫,漂亮,姐姐,113,一个,都让,人好,心动', '其它,国产,免费', 'https://cdn.jsdelivr.net/gh/madouym/images/113.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '187', '339', '545', '400', '04:51', '579', '498', '4.0', '3704', '926', '1632474930', '1632474930', '1631369103', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('66', '18', '2', '0', '二次元动漫漂亮小姐姐111', '', 'erciyuandongmanpiaoliangxiaojiejie111', '1', 'E', '', '二次元动漫漂亮小姐姐111,二次,次元,动漫,漂亮,姐姐,111,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/111.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '127', '242', '848', '935', '04:51', '351', '31', '8.0', '1752', '219', '1632474930', '1632474930', '1632146343', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('67', '18', '2', '0', '二次元动漫漂亮小姐姐112', '', 'erciyuandongmanpiaoliangxiaojiejie112', '1', 'E', '', '二次元动漫漂亮小姐姐112,二次,次元,动漫,漂亮,姐姐,112,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/112.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '330', '726', '70', '830', '04:51', '508', '601', '2.0', '1604', '802', '1632474930', '1632474930', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('68', '18', '2', '0', '二次元动漫漂亮小姐姐109', '', 'erciyuandongmanpiaoliangxiaojiejie109', '1', 'E', '', '二次元动漫漂亮小姐姐109,二次,次元,动漫,漂亮,姐姐,109,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/109.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '167', '613', '15', '65', '04:51', '475', '221', '10.0', '3760', '376', '1632474930', '1632474930', '1631442494', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('69', '18', '2', '0', '二次元动漫漂亮小姐姐110', '', 'erciyuandongmanpiaoliangxiaojiejie110', '1', 'E', '', '二次元动漫漂亮小姐姐110,二次,次元,动漫,漂亮,姐姐,110,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/110.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '735', '957', '534', '263', '04:51', '131', '34', '6.0', '558', '93', '1632474930', '1632474930', '1632140084', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('70', '18', '2', '0', '二次元动漫漂亮小姐姐108', '', 'erciyuandongmanpiaoliangxiaojiejie108', '1', 'E', '', '二次元动漫漂亮小姐姐108,二次,次元,动漫,漂亮,姐姐,108,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/108.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '925', '252', '641', '185', '04:51', '156', '692', '9.0', '8343', '927', '1632474930', '1632474930', '1632197169', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('71', '18', '2', '0', '二次元动漫漂亮小姐姐106', '', 'erciyuandongmanpiaoliangxiaojiejie106', '1', 'E', '', '二次元动漫漂亮小姐姐106,二次,次元,动漫,漂亮,姐姐,106,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/106.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '681', '780', '548', '646', '04:51', '895', '894', '1.0', '394', '394', '1632474930', '1632474930', '1632244656', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('72', '18', '2', '0', '二次元动漫漂亮小姐姐107', '', 'erciyuandongmanpiaoliangxiaojiejie107', '1', 'E', '', '二次元动漫漂亮小姐姐107,二次,次元,动漫,漂亮,姐姐,107,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/107.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '9', '0', '0', '0', '0', '514', '622', '484', '704', '04:51', '802', '375', '5.0', '4865', '973', '1632474930', '1632474930', '1631934703', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('73', '18', '2', '0', '二次元动漫漂亮小姐姐104', '', 'erciyuandongmanpiaoliangxiaojiejie104', '1', 'E', '', '二次元动漫漂亮小姐姐104,二次,次元,动漫,漂亮,姐姐,104,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/104.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '903', '309', '925', '994', '04:51', '86', '408', '2.0', '282', '141', '1632474930', '1632474930', '1632042250', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('74', '18', '2', '0', '二次元动漫漂亮小姐姐105', '', 'erciyuandongmanpiaoliangxiaojiejie105', '1', 'E', '', '二次元动漫漂亮小姐姐105,二次,次元,动漫,漂亮,姐姐,105,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/105.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '7', '847', '885', '465', '04:51', '101', '940', '8.0', '2104', '263', '1632474930', '1632474930', '1610038155', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('75', '18', '2', '0', '二次元动漫漂亮小姐姐103', '', 'erciyuandongmanpiaoliangxiaojiejie103', '1', 'E', '', '二次元动漫漂亮小姐姐103,二次,次元,动漫,漂亮,姐姐,103,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/103.png', '', '', '', '洛天依', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '8', '0', '0', '0', '0', '90', '616', '654', '135', '04:51', '395', '414', '3.0', '2877', '959', '1632474930', '1632474930', '1630758407', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('76', '18', '2', '0', '二次元动漫漂亮小姐姐101', '', 'erciyuandongmanpiaoliangxiaojiejie101', '1', 'E', '', '二次元动漫漂亮小姐姐101,二次,次元,动漫,漂亮,姐姐,101,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/101.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '714', '368', '60', '585', '04:51', '514', '492', '1.0', '375', '375', '1632474930', '1632474930', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('77', '18', '2', '0', '二次元动漫漂亮小姐姐102', '', 'erciyuandongmanpiaoliangxiaojiejie102', '1', 'E', '', '二次元动漫漂亮小姐姐102,二次,次元,动漫,漂亮,姐姐,102,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/102.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '849', '108', '883', '157', '04:51', '226', '33', '1.0', '199', '199', '1632474930', '1632474930', '1631102714', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('78', '18', '2', '0', '二次元动漫漂亮小姐姐100', '', 'erciyuandongmanpiaoliangxiaojiejie100', '1', 'E', '', '二次元动漫漂亮小姐姐100,二次,次元,动漫,漂亮,姐姐,100,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/100.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '619', '646', '503', '597', '04:51', '442', '582', '4.0', '1500', '375', '1632474930', '1632474930', '1632115819', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('79', '18', '2', '0', '二次元动漫漂亮小姐姐99', '', 'erciyuandongmanpiaoliangxiaojiejie99', '1', 'E', '', '二次元动漫漂亮小姐姐99,二次,次元,动漫,漂亮,姐姐,99,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/99.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '417', '65', '473', '562', '04:51', '666', '217', '3.0', '2592', '864', '1632474930', '1632474930', '1625046352', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('80', '18', '2', '0', '二次元动漫漂亮小姐姐98', '', 'erciyuandongmanpiaoliangxiaojiejie98', '1', 'E', '', '二次元动漫漂亮小姐姐98,二次,次元,动漫,漂亮,姐姐,98,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/98.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '525', '179', '764', '902', '04:51', '939', '889', '3.0', '78', '26', '1632474930', '1632474930', '1632197171', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('81', '17', '2', '0', '二次元动漫漂亮小姐姐97', '', 'erciyuandongmanpiaoliangxiaojiejie97', '1', 'E', '', '二次元动漫漂亮小姐姐97,二次,次元,动漫,漂亮,姐姐,97,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/97.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '841', '26', '648', '461', '04:51', '744', '649', '2.0', '1916', '958', '1632474933', '1632474933', '1632244601', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('82', '17', '2', '0', '二次元动漫漂亮小姐姐95', '', 'erciyuandongmanpiaoliangxiaojiejie95', '1', 'E', '', '二次元动漫漂亮小姐姐95,二次,次元,动漫,漂亮,姐姐,95,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/95.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '57', '596', '43', '731', '04:51', '231', '714', '6.0', '210', '35', '1632474933', '1632474933', '1632416415', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('83', '7', '1', '0', '二次元动漫漂亮小姐姐96', '', 'erciyuandongmanpiaoliangxiaojiejie96', '1', 'E', '', '二次元动漫漂亮小姐姐96,二次,次元,动漫,漂亮,姐姐,96,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/96.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '193', '85', '70', '202', '04:51', '789', '240', '2.0', '1062', '531', '1632474934', '1632474934', '1630908300', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('84', '7', '1', '0', '二次元动漫漂亮小姐姐93', '', 'erciyuandongmanpiaoliangxiaojiejie93', '1', 'E', '', '二次元动漫漂亮小姐姐93,二次,次元,动漫,漂亮,姐姐,93,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/93.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '598', '323', '751', '122', '04:51', '758', '466', '6.0', '4800', '800', '1632474934', '1632474934', '1628201328', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('85', '7', '1', '0', '二次元动漫漂亮小姐姐94', '', 'erciyuandongmanpiaoliangxiaojiejie94', '1', 'E', '', '二次元动漫漂亮小姐姐94,二次,次元,动漫,漂亮,姐姐,94,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/94.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '643', '468', '386', '516', '04:51', '479', '943', '8.0', '4992', '624', '1632474934', '1632474934', '1632337396', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('86', '17', '2', '0', '二次元动漫漂亮小姐姐92', '', 'erciyuandongmanpiaoliangxiaojiejie92', '1', 'E', '', '二次元动漫漂亮小姐姐92,二次,次元,动漫,漂亮,姐姐,92,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/92.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '839', '29', '284', '507', '04:51', '355', '621', '2.0', '768', '384', '1632474934', '1632474934', '1632197803', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('87', '17', '2', '0', '二次元动漫漂亮小姐姐90', '', 'erciyuandongmanpiaoliangxiaojiejie90', '1', 'E', '', '二次元动漫漂亮小姐姐90,二次,次元,动漫,漂亮,姐姐,90,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/90.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '908', '375', '382', '357', '04:51', '429', '938', '8.0', '2816', '352', '1632474934', '1632474934', '1629868803', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('88', '17', '2', '0', '二次元动漫漂亮小姐姐91', '', 'erciyuandongmanpiaoliangxiaojiejie91', '1', 'E', '', '二次元动漫漂亮小姐姐91,二次,次元,动漫,漂亮,姐姐,91,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/91.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '402', '511', '741', '191', '04:51', '950', '398', '2.0', '368', '184', '1632474934', '1632474934', '1625160082', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('89', '17', '2', '0', '二次元动漫漂亮小姐姐89', '', 'erciyuandongmanpiaoliangxiaojiejie89', '1', 'E', '', '二次元动漫漂亮小姐姐89,二次,次元,动漫,漂亮,姐姐,89,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/89.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '928', '634', '688', '812', '04:51', '449', '612', '9.0', '612', '68', '1632474934', '1632474934', '1630126362', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('90', '17', '2', '0', '二次元动漫漂亮小姐姐88', '', 'erciyuandongmanpiaoliangxiaojiejie88', '1', 'E', '', '二次元动漫漂亮小姐姐88,二次,次元,动漫,漂亮,姐姐,88,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/88.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '200', '960', '867', '119', '04:51', '925', '798', '10.0', '8190', '819', '1632474934', '1632474934', '1631951878', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('91', '17', '2', '0', '二次元动漫漂亮小姐姐86', '', 'erciyuandongmanpiaoliangxiaojiejie86', '1', 'E', '', '二次元动漫漂亮小姐姐86,二次,次元,动漫,漂亮,姐姐,86,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/86.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '227', '229', '248', '948', '04:51', '287', '295', '7.0', '4242', '606', '1632474934', '1632474934', '1631143468', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('92', '17', '2', '0', '二次元动漫漂亮小姐姐87', '', 'erciyuandongmanpiaoliangxiaojiejie87', '1', 'E', '', '二次元动漫漂亮小姐姐87,二次,次元,动漫,漂亮,姐姐,87,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/87.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '502', '118', '605', '726', '04:51', '145', '211', '8.0', '6264', '783', '1632474934', '1632474934', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('93', '17', '2', '0', '二次元动漫漂亮小姐姐84', '', 'erciyuandongmanpiaoliangxiaojiejie84', '1', 'E', '', '二次元动漫漂亮小姐姐84,二次,次元,动漫,漂亮,姐姐,84,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/84.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '576', '506', '258', '270', '04:51', '382', '422', '7.0', '2058', '294', '1632474934', '1632474934', '1631143285', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('94', '17', '2', '0', '二次元动漫漂亮小姐姐85', '', 'erciyuandongmanpiaoliangxiaojiejie85', '1', 'E', '', '二次元动漫漂亮小姐姐85,二次,次元,动漫,漂亮,姐姐,85,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/85.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '364', '645', '348', '544', '04:51', '49', '40', '1.0', '87', '87', '1632474934', '1632474934', '1632077670', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('95', '17', '2', '0', '二次元动漫漂亮小姐姐83', '', 'erciyuandongmanpiaoliangxiaojiejie83', '1', 'E', '', '二次元动漫漂亮小姐姐83,二次,次元,动漫,漂亮,姐姐,83,一个,都让,人好,心动', '其它,国产,日韩', 'https://cdn.jsdelivr.net/gh/madouym/images/83.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '940', '929', '27', '534', '04:51', '303', '784', '4.0', '3792', '948', '1632474934', '1632474934', '1632241454', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('96', '17', '2', '0', '二次元动漫漂亮小姐姐81', '', 'erciyuandongmanpiaoliangxiaojiejie81', '1', 'E', '', '二次元动漫漂亮小姐姐81,二次,次元,动漫,漂亮,姐姐,81,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/81.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '628', '15', '538', '334', '04:51', '105', '15', '8.0', '2320', '290', '1632474934', '1632474934', '1629166659', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('97', '17', '2', '0', '二次元动漫漂亮小姐姐82', '', 'erciyuandongmanpiaoliangxiaojiejie82', '1', 'E', '', '二次元动漫漂亮小姐姐82,二次,次元,动漫,漂亮,姐姐,82,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/82.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '774', '212', '599', '198', '04:51', '130', '907', '7.0', '1302', '186', '1632474934', '1632474934', '1630743065', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('98', '17', '2', '0', '二次元动漫漂亮小姐姐79', '', 'erciyuandongmanpiaoliangxiaojiejie79', '1', 'E', '', '二次元动漫漂亮小姐姐79,二次,次元,动漫,漂亮,姐姐,79,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/79.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '412', '505', '197', '636', '04:51', '290', '979', '5.0', '2425', '485', '1632474934', '1632474934', '1627759917', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('99', '17', '2', '0', '二次元动漫漂亮小姐姐80', '', 'erciyuandongmanpiaoliangxiaojiejie80', '1', 'E', '', '二次元动漫漂亮小姐姐80,二次,次元,动漫,漂亮,姐姐,80,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/80.png', '', '', '', '初音未来', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '66', '917', '196', '675', '04:51', '349', '479', '5.0', '3630', '726', '1632474934', '1632474934', '1631753417', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('100', '17', '2', '0', '二次元动漫漂亮小姐姐77', '', 'erciyuandongmanpiaoliangxiaojiejie77', '1', 'E', '', '二次元动漫漂亮小姐姐77,二次,次元,动漫,漂亮,姐姐,77,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/77.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '793', '98', '291', '211', '04:51', '74', '7', '7.0', '819', '117', '1632474934', '1632474934', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('101', '6', '1', '0', '二次元动漫漂亮小姐姐78', '', 'erciyuandongmanpiaoliangxiaojiejie78', '1', 'E', '', '二次元动漫漂亮小姐姐78,二次,次元,动漫,漂亮,姐姐,78,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/78.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '150', '737', '493', '729', '04:51', '899', '882', '10.0', '7590', '759', '1632474937', '1632474937', '1630802356', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('102', '7', '1', '0', '二次元动漫漂亮小姐姐75', '', 'erciyuandongmanpiaoliangxiaojiejie75', '1', 'E', '', '二次元动漫漂亮小姐姐75,二次,次元,动漫,漂亮,姐姐,75,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/75.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '451', '919', '149', '956', '04:51', '153', '456', '5.0', '1995', '399', '1632474937', '1632474937', '1632469693', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('103', '7', '1', '0', '二次元动漫漂亮小姐姐76', '', 'erciyuandongmanpiaoliangxiaojiejie76', '1', 'E', '', '二次元动漫漂亮小姐姐76,二次,次元,动漫,漂亮,姐姐,76,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/76.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '967', '332', '731', '206', '04:51', '670', '711', '7.0', '5208', '744', '1632474937', '1632474937', '1629747562', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('104', '7', '1', '0', '二次元动漫漂亮小姐姐74', '', 'erciyuandongmanpiaoliangxiaojiejie74', '1', 'E', '', '二次元动漫漂亮小姐姐74,二次,次元,动漫,漂亮,姐姐,74,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/74.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '450', '240', '470', '271', '04:51', '803', '774', '10.0', '9770', '977', '1632474937', '1632474937', '1627805918', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('105', '7', '1', '0', '二次元动漫漂亮小姐姐73', '', 'erciyuandongmanpiaoliangxiaojiejie73', '1', 'E', '', '二次元动漫漂亮小姐姐73,二次,次元,动漫,漂亮,姐姐,73,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/73.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '299', '293', '529', '460', '04:51', '328', '301', '3.0', '1692', '564', '1632474937', '1632474937', '1630802552', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('106', '7', '1', '0', '二次元动漫漂亮小姐姐72', '', 'erciyuandongmanpiaoliangxiaojiejie72', '1', 'E', '', '二次元动漫漂亮小姐姐72,二次,次元,动漫,漂亮,姐姐,72,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/72.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '353', '468', '212', '707', '04:51', '667', '182', '8.0', '992', '124', '1632474937', '1632474937', '1631333641', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('107', '7', '1', '0', '二次元动漫漂亮小姐姐70', '', 'erciyuandongmanpiaoliangxiaojiejie70', '1', 'E', '', '二次元动漫漂亮小姐姐70,二次,次元,动漫,漂亮,姐姐,70,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/70.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '683', '927', '539', '754', '04:51', '890', '473', '5.0', '2975', '595', '1632474937', '1632474937', '1629868794', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('108', '7', '1', '0', '二次元动漫漂亮小姐姐71', '', 'erciyuandongmanpiaoliangxiaojiejie71', '1', 'E', '', '二次元动漫漂亮小姐姐71,二次,次元,动漫,漂亮,姐姐,71,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/71.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '270', '216', '645', '370', '04:51', '254', '649', '7.0', '1925', '275', '1632474937', '1632474937', '1631126020', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('109', '7', '1', '0', '二次元动漫漂亮小姐姐69', '', 'erciyuandongmanpiaoliangxiaojiejie69', '1', 'E', '', '二次元动漫漂亮小姐姐69,二次,次元,动漫,漂亮,姐姐,69,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/69.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '570', '447', '287', '794', '04:51', '875', '721', '10.0', '7320', '732', '1632474937', '1632474937', '1627351724', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('110', '7', '1', '0', '二次元动漫漂亮小姐姐67', '', 'erciyuandongmanpiaoliangxiaojiejie67', '1', 'E', '', '二次元动漫漂亮小姐姐67,二次,次元,动漫,漂亮,姐姐,67,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/67.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '75', '687', '672', '463', '04:51', '380', '168', '7.0', '6006', '858', '1632474937', '1632474937', '1630802395', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('111', '7', '1', '0', '二次元动漫漂亮小姐姐68', '', 'erciyuandongmanpiaoliangxiaojiejie68', '1', 'E', '', '二次元动漫漂亮小姐姐68,二次,次元,动漫,漂亮,姐姐,68,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/68.png', '', '', '', '东方栀子', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '631', '425', '273', '487', '04:51', '201', '343', '4.0', '3284', '821', '1632474937', '1632474937', '1628659196', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('112', '7', '1', '0', '二次元动漫漂亮小姐姐66', '', 'erciyuandongmanpiaoliangxiaojiejie66', '1', 'E', '', '二次元动漫漂亮小姐姐66,二次,次元,动漫,漂亮,姐姐,66,一个,都让,人好,心动', '其它,国产,中文', 'https://cdn.jsdelivr.net/gh/madouym/images/66.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '565', '314', '44', '705', '04:51', '581', '286', '2.0', '518', '259', '1632474937', '1632474937', '1632379432', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('113', '7', '1', '0', '二次元动漫漂亮小姐姐64', '', 'erciyuandongmanpiaoliangxiaojiejie64', '1', 'E', '', '二次元动漫漂亮小姐姐64,二次,次元,动漫,漂亮,姐姐,64,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/64.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '698', '738', '716', '159', '04:51', '88', '151', '8.0', '2232', '279', '1632474937', '1632474937', '1630890678', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('114', '7', '1', '0', '二次元动漫漂亮小姐姐65', '', 'erciyuandongmanpiaoliangxiaojiejie65', '1', 'E', '', '二次元动漫漂亮小姐姐65,二次,次元,动漫,漂亮,姐姐,65,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/65.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '692', '968', '306', '251', '04:51', '637', '669', '9.0', '8262', '918', '1632474937', '1632474937', '1632041086', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('115', '7', '1', '0', '二次元动漫漂亮小姐姐62', '', 'erciyuandongmanpiaoliangxiaojiejie62', '1', 'E', '', '二次元动漫漂亮小姐姐62,二次,次元,动漫,漂亮,姐姐,62,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/62.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '881', '839', '355', '562', '04:51', '320', '729', '4.0', '276', '69', '1632474937', '1632474937', '1631189937', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('116', '7', '1', '0', '二次元动漫漂亮小姐姐63', '', 'erciyuandongmanpiaoliangxiaojiejie63', '1', 'E', '', '二次元动漫漂亮小姐姐63,二次,次元,动漫,漂亮,姐姐,63,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/63.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '679', '122', '129', '453', '04:51', '285', '111', '4.0', '1832', '458', '1632474937', '1632474937', '1630724041', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('117', '7', '1', '0', '二次元动漫漂亮小姐姐61', '', 'erciyuandongmanpiaoliangxiaojiejie61', '1', 'E', '', '二次元动漫漂亮小姐姐61,二次,次元,动漫,漂亮,姐姐,61,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/61.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '546', '495', '960', '519', '04:51', '446', '46', '2.0', '764', '382', '1632474937', '1632474937', '1631762648', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('118', '7', '1', '0', '二次元动漫漂亮小姐姐60', '', 'erciyuandongmanpiaoliangxiaojiejie60', '1', 'E', '', '二次元动漫漂亮小姐姐60,二次,次元,动漫,漂亮,姐姐,60,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/60.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '844', '565', '368', '812', '04:51', '574', '776', '6.0', '2754', '459', '1632474937', '1632474937', '1629858822', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('119', '6', '1', '0', '二次元动漫漂亮小姐姐58', '', 'erciyuandongmanpiaoliangxiaojiejie58', '1', 'E', '', '二次元动漫漂亮小姐姐58,二次,次元,动漫,漂亮,姐姐,58,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/58.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '208', '306', '324', '18', '04:51', '243', '373', '6.0', '5442', '907', '1632474938', '1632474938', '1631401433', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('120', '6', '1', '0', '二次元动漫漂亮小姐姐59', '', 'erciyuandongmanpiaoliangxiaojiejie59', '1', 'E', '', '二次元动漫漂亮小姐姐59,二次,次元,动漫,漂亮,姐姐,59,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/59.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '5', '1', '239', '319', '04:51', '850', '729', '10.0', '4330', '433', '1632474938', '1632474938', '1630897754', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('121', '5', '1', '0', '二次元动漫漂亮小姐姐56', '', 'erciyuandongmanpiaoliangxiaojiejie56', '1', 'E', '', '二次元动漫漂亮小姐姐56,二次,次元,动漫,漂亮,姐姐,56,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/56.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '696', '423', '319', '259', '04:51', '648', '469', '7.0', '2002', '286', '1632474941', '1632474941', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('122', '5', '1', '0', '二次元动漫漂亮小姐姐57', '', 'erciyuandongmanpiaoliangxiaojiejie57', '1', 'E', '', '二次元动漫漂亮小姐姐57,二次,次元,动漫,漂亮,姐姐,57,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/57.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '374', '71', '299', '699', '04:51', '652', '321', '6.0', '5010', '835', '1632474941', '1632474941', '1630734491', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('123', '5', '1', '0', '二次元动漫漂亮小姐姐55', '', 'erciyuandongmanpiaoliangxiaojiejie55', '1', 'E', '', '二次元动漫漂亮小姐姐55,二次,次元,动漫,漂亮,姐姐,55,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/55.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '7', '569', '519', '294', '04:51', '814', '316', '4.0', '1920', '480', '1632474941', '1632474941', '1630669866', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('124', '6', '1', '0', '二次元动漫漂亮小姐姐53', '', 'erciyuandongmanpiaoliangxiaojiejie53', '1', 'E', '', '二次元动漫漂亮小姐姐53,二次,次元,动漫,漂亮,姐姐,53,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/53.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '76', '637', '768', '153', '04:51', '172', '306', '4.0', '2972', '743', '1632474941', '1632474941', '1631231851', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('125', '6', '1', '0', '二次元动漫漂亮小姐姐54', '', 'erciyuandongmanpiaoliangxiaojiejie54', '1', 'E', '', '二次元动漫漂亮小姐姐54,二次,次元,动漫,漂亮,姐姐,54,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/54.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '206', '959', '590', '729', '04:51', '765', '249', '9.0', '2439', '271', '1632474941', '1632474941', '1631078448', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('126', '6', '1', '0', '二次元动漫漂亮小姐姐52', '', 'erciyuandongmanpiaoliangxiaojiejie52', '1', 'E', '', '二次元动漫漂亮小姐姐52,二次,次元,动漫,漂亮,姐姐,52,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/52.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '990', '678', '831', '164', '04:51', '714', '956', '9.0', '7650', '850', '1632474941', '1632474941', '1630919506', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('127', '6', '1', '0', '二次元动漫漂亮小姐姐51', '', 'erciyuandongmanpiaoliangxiaojiejie51', '1', 'E', '', '二次元动漫漂亮小姐姐51,二次,次元,动漫,漂亮,姐姐,51,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/51.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '723', '41', '241', '651', '04:51', '462', '464', '5.0', '3240', '648', '1632474941', '1632474941', '1631420323', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('128', '6', '1', '0', '二次元动漫漂亮小姐姐50', '', 'erciyuandongmanpiaoliangxiaojiejie50', '1', 'E', '', '二次元动漫漂亮小姐姐50,二次,次元,动漫,漂亮,姐姐,50,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/50.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '993', '939', '633', '627', '04:51', '596', '8', '10.0', '9870', '987', '1632474941', '1632474941', '1632140162', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('129', '6', '1', '0', '二次元动漫漂亮小姐姐48', '', 'erciyuandongmanpiaoliangxiaojiejie48', '1', 'E', '', '二次元动漫漂亮小姐姐48,二次,次元,动漫,漂亮,姐姐,48,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/48.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '942', '319', '900', '856', '04:51', '276', '317', '1.0', '571', '571', '1632474941', '1632474941', '1629165882', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('130', '6', '1', '0', '二次元动漫漂亮小姐姐49', '', 'erciyuandongmanpiaoliangxiaojiejie49', '1', 'E', '', '二次元动漫漂亮小姐姐49,二次,次元,动漫,漂亮,姐姐,49,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/49.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '966', '704', '275', '119', '04:51', '268', '191', '5.0', '2130', '426', '1632474941', '1632474941', '1632402842', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('131', '6', '1', '0', '二次元动漫漂亮小姐姐47', '', 'erciyuandongmanpiaoliangxiaojiejie47', '1', 'E', '', '二次元动漫漂亮小姐姐47,二次,次元,动漫,漂亮,姐姐,47,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/47.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '783', '2', '69', '385', '04:51', '844', '522', '7.0', '1673', '239', '1632474941', '1632474941', '1627453334', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('132', '6', '1', '0', '二次元动漫漂亮小姐姐45', '', 'erciyuandongmanpiaoliangxiaojiejie45', '1', 'E', '', '二次元动漫漂亮小姐姐45,二次,次元,动漫,漂亮,姐姐,45,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/45.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '199', '160', '867', '39', '04:51', '972', '854', '2.0', '706', '353', '1632474941', '1632474941', '1630696574', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('133', '6', '1', '0', '二次元动漫漂亮小姐姐46', '', 'erciyuandongmanpiaoliangxiaojiejie46', '1', 'E', '', '二次元动漫漂亮小姐姐46,二次,次元,动漫,漂亮,姐姐,46,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/46.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '863', '883', '356', '262', '04:51', '588', '576', '10.0', '8170', '817', '1632474941', '1632474941', '1631118508', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('134', '6', '1', '0', '二次元动漫漂亮小姐姐44', '', 'erciyuandongmanpiaoliangxiaojiejie44', '1', 'E', '', '二次元动漫漂亮小姐姐44,二次,次元,动漫,漂亮,姐姐,44,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/44.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '147', '598', '891', '285', '04:51', '789', '625', '9.0', '3888', '432', '1632474941', '1632474941', '1632402722', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('135', '6', '1', '0', '二次元动漫漂亮小姐姐42', '', 'erciyuandongmanpiaoliangxiaojiejie42', '1', 'E', '', '二次元动漫漂亮小姐姐42,二次,次元,动漫,漂亮,姐姐,42,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/42.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '158', '790', '841', '533', '04:51', '470', '421', '10.0', '4170', '417', '1632474941', '1632474941', '1630602822', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('136', '6', '1', '0', '二次元动漫漂亮小姐姐43', '', 'erciyuandongmanpiaoliangxiaojiejie43', '1', 'E', '', '二次元动漫漂亮小姐姐43,二次,次元,动漫,漂亮,姐姐,43,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/43.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '478', '425', '714', '404', '04:51', '855', '638', '8.0', '6536', '817', '1632474941', '1632474941', '1632146363', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('137', '6', '1', '0', '二次元动漫漂亮小姐姐41', '', 'erciyuandongmanpiaoliangxiaojiejie41', '1', 'E', '', '二次元动漫漂亮小姐姐41,二次,次元,动漫,漂亮,姐姐,41,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/41.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '932', '384', '637', '363', '04:51', '448', '240', '1.0', '135', '135', '1632474941', '1632474941', '1629898298', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('138', '6', '1', '0', '二次元动漫漂亮小姐姐38', '', 'erciyuandongmanpiaoliangxiaojiejie38', '1', 'E', '', '二次元动漫漂亮小姐姐38,二次,次元,动漫,漂亮,姐姐,38,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/38.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '967', '68', '808', '413', '04:51', '137', '324', '8.0', '1024', '128', '1632474941', '1632474941', '1628774222', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('139', '6', '1', '0', '二次元动漫漂亮小姐姐39', '', 'erciyuandongmanpiaoliangxiaojiejie39', '1', 'E', '', '二次元动漫漂亮小姐姐39,二次,次元,动漫,漂亮,姐姐,39,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/39.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '247', '371', '702', '591', '04:51', '536', '751', '3.0', '1281', '427', '1632474941', '1632474941', '1631102333', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('140', '6', '1', '0', '二次元动漫漂亮小姐姐36', '', 'erciyuandongmanpiaoliangxiaojiejie36', '1', 'E', '', '二次元动漫漂亮小姐姐36,二次,次元,动漫,漂亮,姐姐,36,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/36.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '956', '861', '68', '911', '04:51', '163', '336', '7.0', '3619', '517', '1632474941', '1632474941', '1631356035', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('141', '5', '1', '0', '二次元动漫漂亮小姐姐37', '', 'erciyuandongmanpiaoliangxiaojiejie37', '1', 'E', '', '二次元动漫漂亮小姐姐37,二次,次元,动漫,漂亮,姐姐,37,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/37.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '84', '390', '425', '755', '04:51', '903', '296', '2.0', '1098', '549', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('142', '5', '1', '0', '二次元动漫漂亮小姐姐35', '', 'erciyuandongmanpiaoliangxiaojiejie35', '1', 'E', '', '二次元动漫漂亮小姐姐35,二次,次元,动漫,漂亮,姐姐,35,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/35.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '36', '434', '823', '157', '04:51', '914', '696', '2.0', '224', '112', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('143', '5', '1', '0', '二次元动漫漂亮小姐姐33', '', 'erciyuandongmanpiaoliangxiaojiejie33', '1', 'E', '', '二次元动漫漂亮小姐姐33,二次,次元,动漫,漂亮,姐姐,33,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/33.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '825', '600', '118', '881', '04:51', '768', '913', '9.0', '1746', '194', '1632474948', '1632474948', '1630959792', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('144', '5', '1', '0', '二次元动漫漂亮小姐姐34', '', 'erciyuandongmanpiaoliangxiaojiejie34', '1', 'E', '', '二次元动漫漂亮小姐姐34,二次,次元,动漫,漂亮,姐姐,34,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/34.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '812', '811', '629', '714', '04:51', '680', '832', '8.0', '4384', '548', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('145', '5', '1', '0', '二次元动漫漂亮小姐姐31', '', 'erciyuandongmanpiaoliangxiaojiejie31', '1', 'E', '', '二次元动漫漂亮小姐姐31,二次,次元,动漫,漂亮,姐姐,31,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/31.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '14', '291', '897', '552', '04:51', '459', '823', '4.0', '248', '62', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('146', '5', '1', '0', '二次元动漫漂亮小姐姐32', '', 'erciyuandongmanpiaoliangxiaojiejie32', '1', 'E', '', '二次元动漫漂亮小姐姐32,二次,次元,动漫,漂亮,姐姐,32,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/32.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '92', '813', '287', '242', '04:51', '271', '435', '1.0', '778', '778', '1632474948', '1632474948', '1630672038', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('147', '5', '1', '0', '二次元动漫漂亮小姐姐30', '', 'erciyuandongmanpiaoliangxiaojiejie30', '1', 'E', '', '二次元动漫漂亮小姐姐30,二次,次元,动漫,漂亮,姐姐,30,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/30.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '249', '606', '308', '373', '04:51', '233', '273', '3.0', '2343', '781', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('148', '5', '1', '0', '二次元动漫漂亮小姐姐28', '', 'erciyuandongmanpiaoliangxiaojiejie28', '1', 'E', '', '二次元动漫漂亮小姐姐28,二次,次元,动漫,漂亮,姐姐,28,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/28.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '143', '149', '817', '33', '04:51', '937', '310', '1.0', '823', '823', '1632474948', '1632474948', '1631125214', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('149', '5', '1', '0', '二次元动漫漂亮小姐姐29', '', 'erciyuandongmanpiaoliangxiaojiejie29', '1', 'E', '', '二次元动漫漂亮小姐姐29,二次,次元,动漫,漂亮,姐姐,29,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/29.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '678', '71', '324', '610', '04:51', '362', '607', '10.0', '2040', '204', '1632474948', '1632474948', '1630680938', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('150', '5', '1', '0', '二次元动漫漂亮小姐姐26', '', 'erciyuandongmanpiaoliangxiaojiejie26', '1', 'E', '', '二次元动漫漂亮小姐姐26,二次,次元,动漫,漂亮,姐姐,26,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/26.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '114', '486', '320', '551', '04:51', '617', '431', '8.0', '5352', '669', '1632474948', '1632474948', '1631950086', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('151', '5', '1', '0', '二次元动漫漂亮小姐姐27', '', 'erciyuandongmanpiaoliangxiaojiejie27', '1', 'E', '', '二次元动漫漂亮小姐姐27,二次,次元,动漫,漂亮,姐姐,27,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/27.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '162', '334', '270', '188', '04:51', '168', '850', '4.0', '3672', '918', '1632474948', '1632474948', '1630574950', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('152', '5', '1', '0', '二次元动漫漂亮小姐姐25', '', 'erciyuandongmanpiaoliangxiaojiejie25', '1', 'E', '', '二次元动漫漂亮小姐姐25,二次,次元,动漫,漂亮,姐姐,25,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/25.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '640', '930', '216', '404', '04:51', '821', '667', '1.0', '802', '802', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('153', '5', '1', '0', '二次元动漫漂亮小姐姐23', '', 'erciyuandongmanpiaoliangxiaojiejie23', '1', 'E', '', '二次元动漫漂亮小姐姐23,二次,次元,动漫,漂亮,姐姐,23,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/23.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '191', '649', '784', '466', '04:51', '994', '901', '10.0', '2030', '203', '1632474948', '1632474948', '1630594812', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('154', '5', '1', '0', '二次元动漫漂亮小姐姐24', '', 'erciyuandongmanpiaoliangxiaojiejie24', '1', 'E', '', '二次元动漫漂亮小姐姐24,二次,次元,动漫,漂亮,姐姐,24,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/24.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '919', '789', '598', '329', '04:51', '503', '908', '8.0', '4032', '504', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('155', '5', '1', '0', '二次元动漫漂亮小姐姐21', '', 'erciyuandongmanpiaoliangxiaojiejie21', '1', 'E', '', '二次元动漫漂亮小姐姐21,二次,次元,动漫,漂亮,姐姐,21,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/21.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '873', '568', '849', '240', '04:51', '321', '610', '6.0', '5976', '996', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('156', '5', '1', '0', '二次元动漫漂亮小姐姐22', '', 'erciyuandongmanpiaoliangxiaojiejie22', '1', 'E', '', '二次元动漫漂亮小姐姐22,二次,次元,动漫,漂亮,姐姐,22,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/22.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '229', '89', '646', '650', '04:51', '209', '627', '2.0', '332', '166', '1632474948', '1632474948', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('157', '20', '2', '0', '二次元动漫漂亮小姐姐19', '', 'erciyuandongmanpiaoliangxiaojiejie19', '1', 'E', '', '二次元动漫漂亮小姐姐19,二次,次元,动漫,漂亮,姐姐,19,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/19.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '971', '952', '461', '532', '04:51', '310', '160', '1.0', '935', '935', '1632474949', '1632474949', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('158', '8', '1', '0', '二次元动漫漂亮小姐姐20', '', 'erciyuandongmanpiaoliangxiaojiejie20', '1', 'E', '', '二次元动漫漂亮小姐姐20,二次,次元,动漫,漂亮,姐姐,20,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/20.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '551', '607', '471', '380', '04:51', '695', '384', '2.0', '302', '151', '1632474949', '1632474949', '1628579486', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('159', '8', '1', '0', '二次元动漫漂亮小姐姐17', '', 'erciyuandongmanpiaoliangxiaojiejie17', '1', 'E', '', '二次元动漫漂亮小姐姐17,二次,次元,动漫,漂亮,姐姐,17,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/17.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '551', '922', '568', '178', '04:51', '746', '549', '8.0', '2280', '285', '1632474949', '1632474949', '1632055856', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('160', '5', '1', '0', '二次元动漫漂亮小姐姐18', '', 'erciyuandongmanpiaoliangxiaojiejie18', '1', 'E', '', '二次元动漫漂亮小姐姐18,二次,次元,动漫,漂亮,姐姐,18,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/18.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '366', '715', '941', '963', '04:51', '44', '984', '10.0', '10000', '1000', '1632474949', '1632474949', '1632319818', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('161', '8', '1', '0', '二次元动漫漂亮小姐姐16', '', 'erciyuandongmanpiaoliangxiaojiejie16', '1', 'E', '', '二次元动漫漂亮小姐姐16,二次,次元,动漫,漂亮,姐姐,16,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/16.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '331', '373', '4', '329', '04:51', '421', '416', '2.0', '214', '107', '1632474952', '1632474952', '1630827793', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('162', '8', '1', '0', '二次元动漫漂亮小姐姐14', '', 'erciyuandongmanpiaoliangxiaojiejie14', '1', 'E', '', '二次元动漫漂亮小姐姐14,二次,次元,动漫,漂亮,姐姐,14,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/14.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '50', '27', '248', '701', '04:51', '865', '270', '10.0', '2460', '246', '1632474952', '1632474952', '1610110475', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('163', '8', '1', '0', '二次元动漫漂亮小姐姐15', '', 'erciyuandongmanpiaoliangxiaojiejie15', '1', 'E', '', '二次元动漫漂亮小姐姐15,二次,次元,动漫,漂亮,姐姐,15,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/15.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '294', '518', '713', '159', '04:51', '477', '993', '9.0', '2331', '259', '1632474952', '1632474952', '1631101719', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('164', '8', '1', '0', '二次元动漫漂亮小姐姐13', '', 'erciyuandongmanpiaoliangxiaojiejie13', '1', 'E', '', '二次元动漫漂亮小姐姐13,二次,次元,动漫,漂亮,姐姐,13,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/13.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '319', '833', '111', '734', '04:51', '909', '209', '5.0', '3805', '761', '1632474952', '1632474952', '1631965044', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('165', '8', '1', '0', '二次元动漫漂亮小姐姐11', '', 'erciyuandongmanpiaoliangxiaojiejie11', '1', 'E', '', '二次元动漫漂亮小姐姐11,二次,次元,动漫,漂亮,姐姐,11,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/11.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '646', '903', '364', '943', '04:51', '324', '630', '4.0', '588', '147', '1632474952', '1632474952', '1632004043', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('166', '8', '1', '0', '二次元动漫漂亮小姐姐12', '', 'erciyuandongmanpiaoliangxiaojiejie12', '1', 'E', '', '二次元动漫漂亮小姐姐12,二次,次元,动漫,漂亮,姐姐,12,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/12.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '738', '823', '463', '33', '04:51', '990', '858', '9.0', '3906', '434', '1632474952', '1632474952', '1632004081', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('167', '8', '1', '0', '二次元动漫漂亮小姐姐10', '', 'erciyuandongmanpiaoliangxiaojiejie10', '1', 'E', '', '二次元动漫漂亮小姐姐10,二次,次元,动漫,漂亮,姐姐,10,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/10.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '163', '899', '751', '896', '04:51', '471', '352', '7.0', '4494', '642', '1632474952', '1632474952', '1630729896', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('168', '8', '1', '0', '二次元动漫漂亮小姐姐8', '', 'erciyuandongmanpiaoliangxiaojiejie8', '1', 'E', '', '二次元动漫漂亮小姐姐8,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/8.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '422', '198', '373', '908', '04:51', '463', '812', '5.0', '2880', '576', '1632474952', '1632474952', '1630888251', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('169', '8', '1', '0', '二次元动漫漂亮小姐姐9', '', 'erciyuandongmanpiaoliangxiaojiejie9', '1', 'E', '', '二次元动漫漂亮小姐姐9,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/9.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '646', '977', '101', '147', '04:51', '240', '481', '3.0', '2472', '824', '1632474952', '1632474952', '1629863103', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('170', '8', '1', '0', '二次元动漫漂亮小姐姐6', '', 'erciyuandongmanpiaoliangxiaojiejie6', '1', 'E', '', '二次元动漫漂亮小姐姐6,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,欧美', 'https://cdn.jsdelivr.net/gh/madouym/images/6.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '111', '591', '883', '45', '04:51', '223', '842', '7.0', '5887', '841', '1632474952', '1632474952', '1630272722', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('171', '8', '1', '0', '二次元动漫漂亮小姐姐7', '', 'erciyuandongmanpiaoliangxiaojiejie7', '1', 'E', '', '二次元动漫漂亮小姐姐7,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产', 'https://cdn.jsdelivr.net/gh/madouym/images/7.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '151', '42', '237', '555', '04:51', '640', '599', '10.0', '6030', '603', '1632474952', '1632474952', '1627777286', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('172', '8', '1', '0', '二次元动漫漂亮小姐姐5', '', 'erciyuandongmanpiaoliangxiaojiejie5', '1', 'E', '', '二次元动漫漂亮小姐姐5,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/5.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '802', '993', '249', '309', '04:51', '398', '845', '8.0', '5064', '633', '1632474952', '1632474952', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('173', '8', '1', '0', '二次元动漫漂亮小姐姐3', '', 'erciyuandongmanpiaoliangxiaojiejie3', '1', 'E', '', '二次元动漫漂亮小姐姐3,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/3.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '538', '490', '613', '623', '04:51', '337', '786', '4.0', '896', '224', '1632474952', '1632474952', '1632140294', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('174', '8', '1', '0', '二次元动漫漂亮小姐姐4', '', 'erciyuandongmanpiaoliangxiaojiejie4', '1', 'E', '', '二次元动漫漂亮小姐姐4,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/4.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '770', '586', '464', '626', '04:51', '677', '425', '4.0', '3956', '989', '1632474952', '1632474952', '0', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('175', '8', '1', '0', '二次元动漫漂亮小姐姐1', '', 'erciyuandongmanpiaoliangxiaojiejie1', '1', 'E', '', '二次元动漫漂亮小姐姐1,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/1.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '45', '681', '475', '363', '04:51', '418', '921', '10.0', '8910', '891', '1632474952', '1632474952', '1630892798', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('176', '8', '1', '0', '二次元动漫漂亮小姐姐2', '', 'erciyuandongmanpiaoliangxiaojiejie2', '1', 'E', '', '二次元动漫漂亮小姐姐2,二次,次元,动漫,漂亮,姐姐,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/2.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '101', '707', '381', '24', '04:51', '289', '171', '8.0', '360', '45', '1632474952', '1632474952', '1631939928', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');
INSERT INTO `mac_vod` VALUES ('177', '8', '1', '0', '二次元动漫漂亮小姐姐40', '', 'erciyuandongmanpiaoliangxiaojiejie40', '1', 'E', '', '二次元动漫漂亮小姐姐40,二次,次元,动漫,漂亮,姐姐,40,一个,都让,人好,心动', '其它,国产,动漫', 'https://cdn.jsdelivr.net/gh/madouym/images/40.png', '', '', '', '', '', '', '', '二次元动漫漂亮小姐姐,每一个都让人好心动!', 'BD', '', '0', '0', '', '', '大陆', '日语', '2020', '', '', '', '', '', '', '', '0', '0', '0', '0', '0', '0', '0', '734', '59', '333', '813', '04:51', '157', '174', '6.0', '3654', '609', '1632474952', '1632474952', '1630770970', '0', '0', '0', '0.0', '', '', '', '', '', '', '', '', '', '<p>二次元动漫漂亮小姐姐,每一个都让人好心动!</p>', 'MaDouYm', 'no', '', 'BD高清$https://cdn.jsdelivr.net/gh/madouym/video/index.m3u8', '', '', '', '', '0', '', '');

-- -----------------------------
-- Table structure for `mac_website`
-- -----------------------------
DROP TABLE IF EXISTS `mac_website`;
CREATE TABLE `mac_website` (
  `website_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `type_id_1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `website_name` varchar(60) NOT NULL DEFAULT '',
  `website_sub` varchar(255) NOT NULL DEFAULT '',
  `website_en` varchar(255) NOT NULL DEFAULT '',
  `website_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `website_letter` char(1) NOT NULL DEFAULT '',
  `website_color` varchar(6) NOT NULL DEFAULT '',
  `website_lock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `website_sort` int(10) NOT NULL DEFAULT '0',
  `website_jumpurl` varchar(255) NOT NULL DEFAULT '',
  `website_pic` varchar(255) NOT NULL DEFAULT '',
  `website_pic_screenshot` text,
  `website_logo` varchar(255) NOT NULL DEFAULT '',
  `website_area` varchar(20) NOT NULL DEFAULT '',
  `website_lang` varchar(10) NOT NULL DEFAULT '',
  `website_level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `website_time` int(10) unsigned NOT NULL DEFAULT '0',
  `website_time_add` int(10) unsigned NOT NULL DEFAULT '0',
  `website_time_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `website_time_make` int(10) unsigned NOT NULL DEFAULT '0',
  `website_time_referer` int(10) unsigned NOT NULL DEFAULT '0',
  `website_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_hits_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_hits_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_hits_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_score` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `website_score_all` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_score_num` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_up` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_down` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer_day` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer_week` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_referer_month` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `website_tag` varchar(100) NOT NULL DEFAULT '',
  `website_class` varchar(255) NOT NULL DEFAULT '',
  `website_remarks` varchar(100) NOT NULL DEFAULT '',
  `website_tpl` varchar(30) NOT NULL DEFAULT '',
  `website_blurb` varchar(255) NOT NULL DEFAULT '',
  `website_content` mediumtext NOT NULL,
  PRIMARY KEY (`website_id`),
  KEY `type_id` (`type_id`),
  KEY `type_id_1` (`type_id_1`),
  KEY `website_name` (`website_name`),
  KEY `website_en` (`website_en`),
  KEY `website_letter` (`website_letter`),
  KEY `website_sort` (`website_sort`),
  KEY `website_lock` (`website_lock`),
  KEY `website_time` (`website_time`),
  KEY `website_time_add` (`website_time_add`),
  KEY `website_time_referer` (`website_time_referer`),
  KEY `website_hits` (`website_hits`),
  KEY `website_hits_day` (`website_hits_day`),
  KEY `website_hits_week` (`website_hits_week`),
  KEY `website_hits_month` (`website_hits_month`),
  KEY `website_time_make` (`website_time_make`),
  KEY `website_score` (`website_score`),
  KEY `website_score_all` (`website_score_all`),
  KEY `website_score_num` (`website_score_num`),
  KEY `website_up` (`website_up`),
  KEY `website_down` (`website_down`),
  KEY `website_level` (`website_level`),
  KEY `website_tag` (`website_tag`),
  KEY `website_class` (`website_class`),
  KEY `website_referer` (`website_referer`),
  KEY `website_referer_day` (`website_referer_day`),
  KEY `website_referer_week` (`website_referer_week`),
  KEY `website_referer_month` (`website_referer_month`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `mac_website`
-- -----------------------------
INSERT INTO `mac_website` VALUES ('3', '4', '0', '3', '', '3', '1', '3', '', '0', '0', 'https://madouym.com', '', '', 'https://cdn.jsdelivr.net/gh/madouym/banner/3.png', '', '', '0', '1632484553', '1632484553', '0', '0', '0', '0', '0', '0', '0', '0.0', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '', '', '', '');
INSERT INTO `mac_website` VALUES ('2', '4', '0', '2', '', '2', '1', '2', '', '0', '0', 'https://madouym.com', '', '', 'https://cdn.jsdelivr.net/gh/madouym/banner/2.png', '', '', '0', '1632484545', '1632484545', '0', '0', '0', '0', '0', '0', '0', '0.0', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '', '', '', '');
INSERT INTO `mac_website` VALUES ('1', '4', '0', '1', '', '1', '1', '1', '', '0', '0', 'https://madouym.com', '', '', 'https://cdn.jsdelivr.net/gh/madouym/banner/1.png', '', '', '0', '1632484533', '1632484533', '0', '0', '0', '0', '0', '0', '0', '0.0', '0', '0', '0', '0', '0', '0', '0', '0', '', '', '', '', '', '');

-- ----------------------------
-- Table structure for mac_admin
-- ----------------------------
DROP TABLE IF EXISTS `mac_admin`;
CREATE TABLE `mac_admin` (
  `admin_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(30) NOT NULL DEFAULT '',
  `admin_pwd` char(32) NOT NULL DEFAULT '',
  `admin_random` char(32) NOT NULL DEFAULT '',
  `admin_status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `admin_auth` text NOT NULL,
  `admin_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_login_num` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_last_login_time` int(10) unsigned NOT NULL DEFAULT '0',
  `admin_last_login_ip` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`admin_id`),
  KEY `admin_name` (`admin_name`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ;