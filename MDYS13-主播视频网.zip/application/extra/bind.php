<?php
return array (
  '7a4856e7b6a1e1a2580a9b69cdc7233c_5' => 6,
  '3c01ee4d3d837b588ff2c641b47ede93_1' => 2,
  '3c01ee4d3d837b588ff2c641b47ede93_2' => 2,
  '3c01ee4d3d837b588ff2c641b47ede93_3' => 2,
  '3c01ee4d3d837b588ff2c641b47ede93_4' => 2,
  '3c01ee4d3d837b588ff2c641b47ede93_5' => 2,
  '3c01ee4d3d837b588ff2c641b47ede93_6' => 2,
);